﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FutarkezeloAPI.Model;

namespace FutarkezeloAPI.Test
{
    internal class UtvonalComparer : IEqualityComparer<Utvonal>
    {
        public bool Equals(Utvonal? x, Utvonal? y)
        {
            return x == null && y == null ||
                x?.UtvonalId == y?.UtvonalId &&
                x?.KezdoPont == y?.KezdoPont &&
                x?.Vegpont == y?.Vegpont &&
                x?.Hossz == y?.Hossz ||
                x?.Forgalom == y?.Forgalom;
        }

        public int GetHashCode([DisallowNull] Utvonal obj) => obj.UtvonalId;
    }
}
