﻿using FutarkezeloAPI.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FutarkezeloAPI.Test
{
    internal class KapcsolatComparer : IEqualityComparer<Kapcsolat>
    {
        public bool Equals(Kapcsolat? x, Kapcsolat? y)
        {
            return x == null && y == null ||
                x?.KapcsolatId == y?.KapcsolatId &&
                x?.FelhasznaloId == y?.FelhasznaloId &&
                x?.Nev == y?.Nev &&
                x?.Email == y?.Email &&
                x?.Telefon == y?.Telefon &&
                x?.Tema == y?.Tema &&
                x?.Uzenet == y?.Uzenet &&
                x?.LetrehozasDatuma == y?.LetrehozasDatuma;
        }

        public int GetHashCode([DisallowNull] Kapcsolat obj) => obj.KapcsolatId;
    }
}
