﻿using FutarkezeloAPI.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace FutarkezeloAPI.Test
{
    internal class CsomagComparer : IEqualityComparer<Csomag>
    {
        public bool Equals(Csomag? x, Csomag? y)
        {
            return x == null && y == null ||
                x?.CsomagId == y?.CsomagId &&
                x?.Leiras == y?.Leiras &&
                x?.Meret == y?.Meret &&
                x?.Suly == y?.Suly &&
                x?.CsomagautomataId == y?.CsomagautomataId &&
                x?.FelhasznaloId == y?.FelhasznaloId;
        }

        public int GetHashCode([DisallowNull] Csomag obj) => obj.CsomagId;
    }
}
