﻿using FutarkezeloAPI.Controllers;
using FutarkezeloAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace FutarkezeloAPI.Test
{
    [TestClass]
    public sealed class UtvonalControllerTest
    {
        UtvonalController? _sut;
        DbContextHelper? _db;

        [TestInitialize]
        public void Initialize()
        {
            _db = new DbContextHelper();
            _sut = new UtvonalController(_db.CreateDbContext());

            var httpContext = new DefaultHttpContext();
            _sut.ControllerContext = new ControllerContext()
            {
                HttpContext = httpContext
            };
        }

        [TestMethod]
        public async Task GetUtvonalList_ReturnsOkUtvonalList()
        {
            var result = (await _sut!.Get()) as OkObjectResult;
            Assert.IsNotNull(result);
            var utvonalList = result.Value as IEnumerable<Utvonal>;
            Assert.IsNotNull(utvonalList);
            foreach (var utvonal in utvonalList)
            {
                Assert.IsTrue(_db?.UtvonalList
                    .Contains(utvonal, new UtvonalComparer()));
            }
            Assert.AreEqual(utvonalList.Count(), _db?.UtvonalList.Count());
        }

        [TestMethod]
        public async Task GetUtvonalList_ReturnsOkEmptyUtvonalList()
        {
            _db?.ClearAll();
            var result = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(result);
            var utvonalList = result.Value as IEnumerable<Utvonal>;
            Assert.IsNotNull(utvonalList);
            Assert.AreEqual(0, utvonalList.Count());
        }

        [TestMethod]
        public async Task GetById_IfIdExists_ReturnsOkUtvonal()
        {
            int existingId = _db!.UtvonalList[index: 0].UtvonalId;
            var result = await _sut!.GetById(existingId);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var returnedUtvonal = okResult!.Value as Utvonal;

            Assert.IsNotNull(returnedUtvonal);
            Assert.AreEqual(existingId, returnedUtvonal.UtvonalId);
        }

        [TestMethod]
        public async Task GetById_IfIdDoesNotExist_ReturnsNotFoundUtvonal()
        {
            int nonExistingId = _db!.UtvonalList.Max(x => x.UtvonalId) + 1;
            var result = await _sut!.GetById(nonExistingId);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task Post_ValidUtvonal_ReturnsCreatedResult()
        {
            var ujUtvonal = new Utvonal {UtvonalId = 999, Forgalom = "Kicsi", Hossz = 300, KezdoPont = "Budapest", Vegpont = "Győr"};
            var result = await _sut!.Post(ujUtvonal);
            Assert.IsInstanceOfType(result, typeof(CreatedResult));

            var createdResult = result as CreatedResult;
            Assert.IsNotNull(createdResult);
        }
        [TestMethod]
        public async Task Post_InvalidUtvonal_ReturnsBadRequest()
        {
            var hianyosUtvonal = new Utvonal {  };
            _sut!.ModelState.AddModelError("Kezdopont", "Required");
            var result = await _sut!.Post(hianyosUtvonal);

            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }
        [TestMethod]
        public async Task Put_ExistingId_UpdatesDataAndReturnsOkUtvonal() 
        {
            var options = new DbContextOptionsBuilder<Context>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            await using var context = new Context(options);

            var seedUtvonal = new Utvonal
            {
                UtvonalId = 1,
                KezdoPont = "nemtudom",
                Vegpont = "valahol",
                Hossz = 100,
                Forgalom = "brutális"
            };
            context.Utvonalak.Add(seedUtvonal);
            await context.SaveChangesAsync();

            var controller = new UtvonalController(context);

            var frissitettAdatok = new Utvonal
            {
                UtvonalId = 1,
                KezdoPont = "tudom",
                Vegpont = "hol",
                Hossz = 100,
                Forgalom = "brutális"
            };

            var result = await controller.Put(1, frissitettAdatok);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var visszakapottUtvonal = okResult!.Value as Utvonal;

            Assert.IsNotNull(visszakapottUtvonal);
            Assert.AreEqual("tudom", visszakapottUtvonal.KezdoPont);
            Assert.AreEqual("hol", visszakapottUtvonal.Vegpont);

        }

        [TestMethod]
        public async Task Put_NonExistingId_ReturnsNotFoundUtvonal()
        {
            var frissitettAdatok = new Utvonal { UtvonalId = 999, KezdoPont = "Szombathely", Vegpont = "Szombathely", Forgalom = "nincs", Hossz = 3 };
            var result = await _sut!.Put(999, frissitettAdatok);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task Delete_ExistingId_RemovesUtvonalAndReturnsOk()
        {
            var torlendoUtvonal = new Utvonal { UtvonalId = 10, KezdoPont = "Bangladesh", Vegpont = "San Francisco", Hossz = 12200};
            _db!.Context.Utvonalak.Add(torlendoUtvonal);
            await _db.Context.SaveChangesAsync();

            var result = await _sut!.Delete(10);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var visszakapottUtvonal = okResult!.Value as Utvonal;

            Assert.IsNotNull(visszakapottUtvonal);
            Assert.AreEqual(10, visszakapottUtvonal.UtvonalId);

            var letezikE = await _db.Context.Utvonalak.AnyAsync(p => p.UtvonalId == 10);
            Assert.IsFalse(letezikE);
        }

        [TestMethod]
        public async Task Delete_NonExistingId_ReturnsNotFoundUtvonal()
        {
            int nemLetezoId = 99;
            var result = await _sut!.Delete(nemLetezoId);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task TestAll_ReturnsOk()
        {
            #region Create
            var newUtvonal = new Utvonal
            {
                UtvonalId = 10,
                KezdoPont = "",
                Vegpont = "",
                Hossz = 220,
                Forgalom = "erős"
            };
            var created = await _sut!.Post(newUtvonal) as CreatedResult;
            Assert.IsNotNull(created);
            var utvonal = created.Value as Utvonal;
            Assert.IsNotNull(utvonal);
            #endregion

            #region Update
            utvonal.KezdoPont = "Budapest";
            utvonal.Vegpont = "Győr";
            utvonal.Hossz = 120;
            var updated = await _sut!.Put(utvonal.UtvonalId, utvonal) as OkObjectResult;
            Assert.IsNotNull(updated);
            utvonal = updated.Value as Utvonal;
            Assert.IsNotNull(utvonal);
            #endregion

            #region Get
            var geted = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(geted);
            #endregion

            #region Delete
            var deleted = await _sut!.Delete(utvonal.UtvonalId) as OkObjectResult;
            Assert.IsNotNull(deleted);
            utvonal = deleted.Value as Utvonal;
            Assert.IsNotNull(utvonal);
            #endregion
        }
    }
}
