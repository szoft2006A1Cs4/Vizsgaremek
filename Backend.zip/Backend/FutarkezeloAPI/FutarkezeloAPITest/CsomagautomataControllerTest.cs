﻿using FutarkezeloAPI.Controllers;
using FutarkezeloAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace FutarkezeloAPI.Test
{
    [TestClass]
    public sealed class CsomagautomataControllerTest
    {
        CsomagautomataController? _sut;
        DbContextHelper? _db;

        [TestInitialize]
        public void Initialize()
        {
            _db = new DbContextHelper();
            _sut = new CsomagautomataController(_db.CreateDbContext());

            var httpContext = new DefaultHttpContext();
            _sut.ControllerContext = new ControllerContext()
            {
                HttpContext = httpContext
            };
        }

        [TestMethod]
        public async Task GetCsomagautomataList_ReturnsOkCsomagautomataList()
        {
            var result = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(result);
            var csomagautomataList = result.Value as IEnumerable<Csomagautomata>;
            Assert.IsNotNull(csomagautomataList);
            foreach (var csomagautomata in csomagautomataList)
            {
                Assert.IsTrue(_db?.CsomagautomataList
                    .Contains(csomagautomata, new CsomagautomataComparer()));
            }
            Assert.AreEqual(csomagautomataList.Count(), _db?.CsomagautomataList.Count());
        }

        [TestMethod]
        public async Task GetCsomagautomataList_ReturnsOkEmptyCsomagautomataList()
        {
            _db?.ClearAll();
            var result = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(result);
            var csomagautomataList = result.Value as IEnumerable<Csomagautomata>;
            Assert.IsNotNull(csomagautomataList);
            Assert.AreEqual(0, csomagautomataList.Count());
        }

        [TestMethod]
        public async Task GetById_IfIdExists_ReturnsOkCsomagautomata()
        {
            int existingId = _db!.CsomagautomataList[index: 0].CsomagautomataId;
            var result = await _sut!.GetById(existingId);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var returnedCsomagautomata = okResult!.Value as Csomagautomata;

            Assert.IsNotNull(returnedCsomagautomata);
            Assert.AreEqual(existingId, returnedCsomagautomata.CsomagautomataId);
        }

        [TestMethod]
        public async Task GetById_IfIdDoesNotExist_ReturnsNotFoundCsomagautomata()
        {
            int nonExistingId = _db!.CsomagautomataList.Max(x => x.CsomagautomataId) + 1;
            var result = await _sut!.GetById(nonExistingId);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task Post_ValidCsomagautomata_ReturnsCreatedResult()
        {
            var ujCsomagautomata = new Csomagautomata { CsomagautomataId = 6, Helyszin = "Bikini Fenék", Nyitvatartas = "Mindig", UtvonalId = 6, Lat = 46.12121m, Lng = 45.13131m, Iranyitoszam = 6500 };
            var result = await _sut!.Post(ujCsomagautomata);
            Assert.IsInstanceOfType(result, typeof(CreatedResult));

            var createdResult = result as CreatedResult;
            Assert.IsNotNull(createdResult);
        }
        [TestMethod]
        public async Task Post_InvalidCsomagautomata_ReturnsBadRequest()
        {
            var hianyosCsomagautomata = new Csomagautomata { UtvonalId = 1};
            _sut!.ModelState.AddModelError("Helyszin", "Required");
            var result = await _sut!.Post(hianyosCsomagautomata);

            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }
        [TestMethod]
        public async Task Put_ExistingId_UpdatesDataAndReturnsOkCsomagautomata()
        {
            var options = new DbContextOptionsBuilder<Context>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            await using var context = new Context(options);

            var seedCsomagautomata = new Csomagautomata
            {
                CsomagautomataId = 1,
                Helyszin = "Bikini fenék",
                Nyitvatartas = "néha",
                Lat = 46.12121m,
                Lng = 45.13131m,
                Iranyitoszam = 6500,
                UtvonalId = 1
            };
            context.Csomagautomatak.Add(seedCsomagautomata);
            await context.SaveChangesAsync();

            var controller = new CsomagautomataController(context);

            var frissitettAdatok = new Csomagautomata
            {
                CsomagautomataId = 1,
                Helyszin = "Veszélyes vödör",
                Nyitvatartas = "igen",
                Lat = 46.32154m,
                Lng = 44.36131m,
                Iranyitoszam = 6800,
                UtvonalId = 1
            };

            var result = await controller.Put(1, frissitettAdatok);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var visszakapottCsomagautomata = okResult!.Value as Csomagautomata;

            Assert.IsNotNull(visszakapottCsomagautomata);
            Assert.AreEqual("Veszélyes vödör", visszakapottCsomagautomata.Helyszin);
            Assert.AreEqual("igen", visszakapottCsomagautomata.Nyitvatartas);
        }

        [TestMethod]
        public async Task Put_NonExistingId_ReturnsNotFoundCsomagautomata()
        {
            var frissitettAdatok = new Csomagautomata { CsomagautomataId = 999, Helyszin = "Messze", Nyitvatartas = "Nem", Lat = 45.32326m, Lng = 45.36698m, Iranyitoszam = 1100, UtvonalId = 999 };
            var result = await _sut!.Put(999, frissitettAdatok); 
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task Delete_ExistingId_RemovesCsomagautomataAndReturnsOk()
        {
            var torlendoCsomagautomata = new Csomagautomata { CsomagautomataId = 6, Helyszin = "Budapest", Nyitvatartas = "0-24", Lat = 46.52625m, Lng = 47.32621m, Iranyitoszam = 6500, UtvonalId = 6};
            _db!.Context.Csomagautomatak.Add(torlendoCsomagautomata);
            await _db.Context.SaveChangesAsync();

            var result = await _sut!.Delete(6);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var visszakapottCsomagautomata = okResult!.Value as Csomagautomata;

            Assert.IsNotNull(visszakapottCsomagautomata);
            Assert.AreEqual(6, visszakapottCsomagautomata.CsomagautomataId);

            var letezikE = await _db.Context.Csomagautomatak.AnyAsync(p => p.CsomagautomataId == 6);
            Assert.IsFalse(letezikE);
        }

        [TestMethod]
        public async Task Delete_NonExistingId_ReturnsNotFoundCsomagautomata()
        {
            int nemLetezoId = 99;
            var result = await _sut!.Delete(nemLetezoId);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task TestAll_ReturnsOk()
        {
            #region Create
            var newCsomagautomata = new Csomagautomata
            {
                CsomagautomataId = 10,
                UtvonalId = 10,
                Helyszin = "Budapest, Ulászló u. 17",
                Nyitvatartas = "null-huszonnégy",
                Lat = 44.12121m,
                Lng = 43.13131m,
                Iranyitoszam = 1007

            };
            var created = await _sut!.Post(newCsomagautomata) as CreatedResult;
            Assert.IsNotNull(created);
            var csomagautomata = created.Value as Csomagautomata;
            Assert.IsNotNull(csomagautomata);
            #endregion

            #region Update
            csomagautomata.Helyszin = "Budapest, Alkotás u. 53";
            csomagautomata.Nyitvatartas = "kettotol-husz";
            csomagautomata.Iranyitoszam = 1070;
            var updated = await _sut!.Put(csomagautomata.CsomagautomataId, csomagautomata) as OkObjectResult;
            Assert.IsNotNull(updated);
            csomagautomata = updated.Value as Csomagautomata;
            Assert.IsNotNull(csomagautomata);
            #endregion

            #region Get
            var geted = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(geted);
            #endregion

            #region Delete
            var deleted = await _sut!.Delete(csomagautomata.CsomagautomataId) as OkObjectResult;
            Assert.IsNotNull(deleted);
            csomagautomata = deleted.Value as Csomagautomata;
            Assert.IsNotNull(csomagautomata);
            #endregion
        }
    }
}
