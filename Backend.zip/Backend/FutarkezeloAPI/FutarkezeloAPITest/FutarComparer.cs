﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FutarkezeloAPI.Model;

namespace FutarkezeloAPI.Test
{
    internal class FutarComparer : IEqualityComparer<Futar>
    {
        public bool Equals(Futar? x, Futar? y)
        {
            return x == null && y == null ||
                x?.FutarId == y?.FutarId &&
                x?.Nev == y?.Nev &&
                x?.Elerhetoseg == y?.Elerhetoseg &&
                x?.Jogositvany_Tipus == y?.Jogositvany_Tipus &&
                x?.Munka_Kezdese == y?.Munka_Kezdese &&
                x?.JarmuId == y?.JarmuId;
        }

        public int GetHashCode([DisallowNull] Futar obj) => obj.FutarId;
    }
}
