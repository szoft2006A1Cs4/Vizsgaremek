﻿using FutarkezeloAPI.Controllers;
using FutarkezeloAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace FutarkezeloAPI.Test
{
    [TestClass]
    public sealed class FelhasznaloControllerTest
    {
        FelhasznaloController? _sut; 
        DbContextHelper? _db;

        [TestInitialize]
        public void Initialize()
        {
            _db = new DbContextHelper();
            _sut = new FelhasznaloController(_db.CreateDbContext());

            var httpContext = new DefaultHttpContext();
            _sut.ControllerContext = new ControllerContext()
            {
                HttpContext = httpContext
            };
        }

        [TestMethod]
        public async Task GetFelhasznaloList_ReturnsOkCsomagList()
        {
            var result = (await _sut!.Get()) as OkObjectResult;
            Assert.IsNotNull(result);
            var felhasznaloList = result.Value as IEnumerable<Felhasznalo>;
            Assert.IsNotNull(felhasznaloList);
            foreach (var felhasznalo in felhasznaloList)
            {
                Assert.IsTrue(_db?.FelhasznaloList
                    .Contains(felhasznalo, new FelhasznaloComparer()));
            }
            Assert.AreEqual(felhasznaloList.Count(), _db?.FelhasznaloList.Count());
        }

        [TestMethod]
        public async Task GetFelhasznaloList_ReturnsOkEmptyFelhasznaloList()
        {
            _db?.ClearAll();
            var result = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(result);
            var felhasznaloList = result.Value as IEnumerable<Felhasznalo>;
            Assert.IsNotNull(felhasznaloList);
            Assert.AreEqual(0, felhasznaloList.Count());
        }

        [TestMethod]
        public async Task GetById_IfIdExists_ReturnsOkFelhasznalo()
        {
            int existingId = _db!.FelhasznaloList[index: 0].FelhasznaloId;
            var result = await _sut!.GetById(existingId);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var returnedFelhasznalo = okResult!.Value as Felhasznalo;

            Assert.IsNotNull(returnedFelhasznalo);
            Assert.AreEqual(existingId, returnedFelhasznalo.FelhasznaloId);
        }

        [TestMethod]
        public async Task GetById_IfIdDoesNotExist_ReturnsNotFoundFelhasznalo()
        {
            int nonExistingId = _db!.FelhasznaloList.Max(x => x.FelhasznaloId) + 1;
            var result = await _sut!.GetById(nonExistingId);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task Post_ValidFelhasznalo_ReturnsCreatedResult()
        {
            var ujFelhasznalo = new Felhasznalo {FelhasznaloId = 999, Nev = "Elek", Email = "teszt@gmail.com", Telefonszam = "+3698735251", Jelszo = "jelszo", Jogosultsag = "user"};
            var result = await _sut!.Post(ujFelhasznalo);
            Assert.IsInstanceOfType(result, typeof(CreatedResult));

            var createdResult = result as CreatedResult;
            Assert.IsNotNull(createdResult);
        }
        [TestMethod]
        public async Task Post_InvalidFelhasznalo_ReturnsBadRequest()
        {
            var hianyosFelhasznalo = new Felhasznalo { };
            _sut!.ModelState.AddModelError("Nev", "Required");
            var result = await _sut!.Post(hianyosFelhasznalo);

            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }
        [TestMethod]
        public async Task Put_ExistingId_UpdatesDataAndReturnsOkFelhasznalo()
        {
            var options = new DbContextOptionsBuilder<Context>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            await using var context = new Context(options);

            var seedFelhasznalo = new Felhasznalo
            {
                FelhasznaloId = 1,
                Nev = "Pista",
                Email = "pista@gmail.com",
                Telefonszam = "+36701111111",
                Jelszo = "jelszo",
                Jogosultsag = "user"
            };
            context.Felhasznalok.Add(seedFelhasznalo);
            await context.SaveChangesAsync();

            var controller = new FelhasznaloController(context);

            var frissitettAdatok = new Felhasznalo
            {
                FelhasznaloId = 1,
                Nev = "Jani",
                Email = "jani@gmail.com",
                Telefonszam = "+3670112411",
                Jelszo = "jelszo",
                Jogosultsag = "user"
            };

            var result = await controller.Put(1, frissitettAdatok);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var visszakapottFelhasznalo = okResult!.Value as Felhasznalo;

            Assert.IsNotNull(visszakapottFelhasznalo);
            Assert.AreEqual("Jani", visszakapottFelhasznalo.Nev);
            Assert.AreEqual("jani@gmail.com", visszakapottFelhasznalo.Email);

        }

        [TestMethod]
        public async Task Put_NonExistingId_ReturnsNotFoundFelhasznalo() 
        {
            var frissitettAdatok = new Felhasznalo {FelhasznaloId = 999, Nev = "Pista", Email = "teszt@gmail.com", Telefonszam = "+3698735251", Jelszo = "jelszo", Jogosultsag = "user" };
            var result = await _sut!.Put(999, frissitettAdatok);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task Delete_ExistingId_RemovesCsomagAndReturnsOk()
        {
            var torlendoFelhasznalo = new Felhasznalo {FelhasznaloId = 999, Nev = "Pista",  Email = "teszt@gmail.com", Telefonszam = "+3698735251", Jelszo = "jelszo", Jogosultsag = "user" };
            _db!.Context.Felhasznalok.Add(torlendoFelhasznalo);
            await _db.Context.SaveChangesAsync();

            var result = await _sut!.Delete(999);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var visszakapottFelhasznalo = okResult!.Value as Felhasznalo;

            Assert.IsNotNull(visszakapottFelhasznalo);
            Assert.AreEqual(999, visszakapottFelhasznalo.FelhasznaloId);

            var letezikE = await _db.Context.Felhasznalok.AnyAsync(p => p.FelhasznaloId == 999);
            Assert.IsFalse(letezikE);
        }

        [TestMethod]
        public async Task Delete_NonExistingId_ReturnsNotFoundFelhasznalo()
        {
            int nemLetezoId = 99;
            var result = await _sut!.Delete(nemLetezoId);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task TestAll_ReturnsOk()
        {
            #region Create
            var newFelhasznalo = new Felhasznalo
            {
                FelhasznaloId = 20,
                Email = "sanyi.nagy@gmail.com",
                Jelszo = "sanyikertje12",
                Jogosultsag = "User",
                Nev = "Nagy Sanyi",
                Telefonszam = "123456789"                
            };
            var created = await _sut!.Post(newFelhasznalo) as CreatedResult;
            Assert.IsNotNull(created);
            var felhasznalo = created.Value as Felhasznalo;
            Assert.IsNotNull(felhasznalo);
            #endregion

            #region Update
            felhasznalo.Jelszo = "sanyi_almása";
            felhasznalo.Nev = "Nagy Sanyi";
            var updated = await _sut!.Put(felhasznalo.FelhasznaloId, felhasznalo) as OkObjectResult;
            Assert.IsNotNull(updated);
            felhasznalo = updated.Value as Felhasznalo;
            Assert.IsNotNull(felhasznalo);
            #endregion

            #region Get
            var geted = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(geted);
            #endregion

            #region Delete
            var deleted = await _sut!.Delete(felhasznalo.FelhasznaloId) as OkObjectResult;
            Assert.IsNotNull(deleted);
            felhasznalo = deleted.Value as Felhasznalo;
            Assert.IsNotNull(felhasznalo);
            #endregion
        }
    }
}
