﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FutarkezeloAPI.Model;

namespace FutarkezeloAPI.Test
{
    internal class FelhasznaloComparer : IEqualityComparer<Felhasznalo>
    {
        public bool Equals(Felhasznalo? x, Felhasznalo? y)
        {
            return x == null && y == null ||
                x?.FelhasznaloId == y?.FelhasznaloId &&
                x?.Nev == y?.Nev &&
                x?.Email == y?.Email &&
                x?.Telefonszam == y?.Telefonszam &&
                x?.Jelszo == y?.Jelszo &&
                x?.Jogosultsag == y?.Jogosultsag;
        }

        public int GetHashCode([DisallowNull] Felhasznalo obj) => obj.FelhasznaloId;
    }
}
