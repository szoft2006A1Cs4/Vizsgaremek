﻿using FutarkezeloAPI.Controllers;
using FutarkezeloAPI.Model;
using JarmukezeloAPI.Controllers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace FutarkezeloAPI.Test
{
    [TestClass]
    public sealed class JarmuControllerTest
    {
        JarmuController? _sut;
        DbContextHelper? _db;

        [TestInitialize]
        public void Initialize()
        {
            _db = new DbContextHelper();
            _sut = new JarmuController(_db.CreateDbContext());

            var httpContext = new DefaultHttpContext();
            _sut.ControllerContext = new ControllerContext()
            {
                HttpContext = httpContext
            };
        }

        [TestMethod]
        public async Task GetJarmuList_ReturnsOkJarmuList()
        {
            var result = (await _sut!.Get()) as OkObjectResult;
            Assert.IsNotNull(result);
            var jarmuList = result.Value as IEnumerable<Jarmu>;
            Assert.IsNotNull(jarmuList);
            foreach (var jarmu in jarmuList)
            {
                Assert.IsTrue(_db?.JarmuList
                    .Contains(jarmu, new JarmuComparer()));
            }
            Assert.AreEqual(jarmuList.Count(), _db?.JarmuList.Count());
        }

        [TestMethod]
        public async Task GetJarmuList_ReturnsOkEmptyJarmuList()
        {
            _db?.ClearAll();
            var result = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(result);
            var jarmuList = result.Value as IEnumerable<Jarmu>;
            Assert.IsNotNull(jarmuList);
            Assert.AreEqual(0, jarmuList.Count());
        }

        [TestMethod]
        public async Task GetById_IfIdExists_ReturnsOkJarmu()
        {
            int existingId = _db!.JarmuList[index: 0].JarmuId;
            var result = await _sut!.GetById(existingId);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var returnedJarmu = okResult!.Value as Jarmu;

            Assert.IsNotNull(returnedJarmu);
            Assert.AreEqual(existingId, returnedJarmu.JarmuId);
        }

        [TestMethod]
        public async Task GetById_IfIdDoesNotExist_ReturnsNotFoundJarmu()
        {
            int nonExistingId = _db!.JarmuList.Max(x => x.JarmuId) + 1;
            var result = await _sut!.GetById(nonExistingId);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task Post_ValidJarmu_ReturnsCreatedResult()
        {
            var ujJarmu = new Jarmu { JarmuId = 999, Allapot = "Jó", Rendszam = "AAA-111", Kapacitas_Kg = 1000, Tipus = "Helikopter"};
            var result = await _sut!.Post(ujJarmu);
            Assert.IsInstanceOfType(result, typeof(CreatedResult));

            var createdResult = result as CreatedResult;
            Assert.IsNotNull(createdResult);
        }
        [TestMethod]
        public async Task Post_InvalidJarmu_ReturnsBadRequest()
        {
            var hianyosJarmu = new Jarmu {};
            _sut!.ModelState.AddModelError("Rendszam", "Required");
            var result = await _sut!.Post(hianyosJarmu);

            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }
        [TestMethod]
        public async Task Put_ExistingId_UpdatesDataAndReturnsOkJarmu()
        {
            var options = new DbContextOptionsBuilder<Context>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            await using var context = new Context(options);

            var seedJarmu = new Jarmu
            {
                JarmuId = 1,
                Tipus = "Tank",
                Kapacitas_Kg = 10,
                Rendszam = "AAA-000",
                Allapot = "Király"
            };
            context.Jarmuk.Add(seedJarmu);
            await context.SaveChangesAsync();

            var controller = new JarmuController(context);

            var frissitettAdatok = new Jarmu
            {
                JarmuId = 1,
                Tipus = "Tank",
                Kapacitas_Kg = 10000,
                Rendszam = "AAA-000",
                Allapot = "Király"
            };

            var result = await controller.Put(1, frissitettAdatok);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var visszakapottJarmu = okResult!.Value as Jarmu;

            Assert.IsNotNull(visszakapottJarmu);
            Assert.AreEqual(10000, visszakapottJarmu.Kapacitas_Kg);

        }

        [TestMethod]
        public async Task Put_NonExistingId_ReturnsNotFoundJarmu()
        {
            var frissitettAdatok = new Jarmu { JarmuId = 999, Kapacitas_Kg = 100, Allapot = "Tragacs",  Rendszam = "AAA-111", Tipus = "Vonat" };
            var result = await _sut!.Put(999, frissitettAdatok);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task Delete_ExistingId_RemovesJarmuAndReturnsOk()
        {
            var torlendoJarmu = new Jarmu {JarmuId = 10, Tipus = "bicikli", Rendszam = "AAA-111", Allapot = "közepes", Kapacitas_Kg = 30 };
            _db!.Context.Jarmuk.Add(torlendoJarmu);
            await _db.Context.SaveChangesAsync();

            var result = await _sut!.Delete(10);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var visszakapottJarmu = okResult!.Value as Jarmu;

            Assert.IsNotNull(visszakapottJarmu);
            Assert.AreEqual(10, visszakapottJarmu.JarmuId);

            var letezikE = await _db.Context.Jarmuk.AnyAsync(p => p.JarmuId == 10);
            Assert.IsFalse(letezikE);
        }

        [TestMethod]
        public async Task Delete_NonExistingId_ReturnsNotFoundJarmu()
        {
            int nemLetezoId = 99;
            var result = await _sut!.Delete(nemLetezoId);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task TestAll_ReturnsOk()
        {
            #region Create
            var newJarmu = new Jarmu
            {
                JarmuId = 10,
                Rendszam = "DV-GF-63",
                Allapot = "Használatban",
                Kapacitas_Kg = 600,
                Tipus = "Furgon"
            };
            var created = await _sut!.Post(newJarmu) as CreatedResult;
            Assert.IsNotNull(created);
            var jarmu = created.Value as Jarmu;
            Assert.IsNotNull(jarmu);
            #endregion

            #region Update
            jarmu.Allapot = "Szervízben";
            jarmu.Kapacitas_Kg = 700;
            var updated = await _sut!.Put(jarmu.JarmuId, jarmu) as OkObjectResult;
            Assert.IsNotNull(updated);
            jarmu = updated.Value as Jarmu;
            Assert.IsNotNull(jarmu);
            #endregion

            #region Get
            var geted = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(geted);
            #endregion

            #region Delete
            var deleted = await _sut!.Delete(jarmu.JarmuId) as OkObjectResult;
            Assert.IsNotNull(deleted);
            jarmu = deleted.Value as Jarmu;
            Assert.IsNotNull(jarmu);
            #endregion
        }
    }
}
