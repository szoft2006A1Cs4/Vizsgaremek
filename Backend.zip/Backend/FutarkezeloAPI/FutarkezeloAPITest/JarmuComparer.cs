﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FutarkezeloAPI.Model;

namespace FutarkezeloAPI.Test
{
    internal class JarmuComparer : IEqualityComparer<Jarmu>
    {
        public bool Equals(Jarmu? x, Jarmu? y)
        {
            return x == null && y == null ||
                x?.JarmuId == y?.JarmuId &&
                x?.Rendszam == y?.Rendszam &&
                x?.Tipus == y?.Tipus &&
                x?.Kapacitas_Kg == y?.Kapacitas_Kg &&
                x?.Allapot == y?.Allapot;    
        }
    
        public int GetHashCode([DisallowNull] Jarmu obj) => obj.JarmuId;
    }
}
