﻿using FutarkezeloAPI.Auth;
using FutarkezeloAPI.Controllers;
using FutarkezeloAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace FutarkezeloAPI.Test
{
    [TestClass]
    public sealed class JelentkezesControllerTest
    {
        JelentkezesController? _sut;
        DbContextHelper? _db;

        [TestInitialize]
        public void Initialize()
        {
            _db = new DbContextHelper();
            _sut = new JelentkezesController(_db.CreateDbContext());
            var httpContext = new DefaultHttpContext();
            _sut.ControllerContext = new ControllerContext()
            {
                HttpContext = httpContext
            };
        }

        [TestMethod]
        public async Task GetJelentkezesList_ReturnsOkJelentkezesList()
        {
            var result = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(result);
            var jelentkezesList = result.Value as IEnumerable<Jelentkezes>;
            Assert.IsNotNull(jelentkezesList);
            foreach (var jelentkezes in jelentkezesList)
            {
                Assert.IsTrue(_db?.JelentkezesList
                    .Contains(jelentkezes, new JelentkezesComparer()));
            }
            Assert.AreEqual(jelentkezesList.Count(), _db?.JelentkezesList.Count());
        }



        [TestMethod]
        public async Task GetById_IfIdExists_ReturnsOkJelentkezes()
        {
            int existingId = _db!.JelentkezesList[index: 0].JelentkezesId;
            var result = await _sut!.GetById(existingId);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var returnedJelentkezes = okResult!.Value as Jelentkezes;

            Assert.IsNotNull(returnedJelentkezes);
            Assert.AreEqual(existingId, returnedJelentkezes.JelentkezesId);
        }

        [TestMethod]
        public async Task GetById_IfIdDoesNotExist_ReturnsNotFoundJelentkezes()
        {
            int nonExistingId = _db!.JelentkezesList.Max(x => x.JelentkezesId) + 1;
            var result = await _sut!.GetById(nonExistingId);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task Post_ValidJelentkezes_ReturnsCreatedResult()
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, "1")
            };
            var identity = new ClaimsIdentity(claims, "TestAuth");
            var claimsPrincipal = new ClaimsPrincipal(identity);
            _sut!.ControllerContext.HttpContext.User = claimsPrincipal;

            _sut!.Request.Scheme = "http";
            _sut.Request.Host = new HostString("localhost");

            var ujJelentkezes = new Jelentkezes { JelentkezesId = 10, Nev = "Csaba Bálint", Email = "balint.csaba@gmail.com", Telefon = "+36309867542", Lakohely = "Szombathely", Pozicio = "ugyfelszolgalat", Tapasztalat = "igen", Bemutatkozas = "Rosszul vagyok az emberektől.", Letrehozva = DateTime.Now};
            var result = await _sut!.Post(ujJelentkezes);
            Assert.IsInstanceOfType(result, typeof(CreatedResult));
            
            var createdResult = result as CreatedResult;
            Assert.IsNotNull(createdResult);
        }
        [TestMethod]
        public async Task Post_InvalidJelentkezes_ReturnsBadRequest()
        {
            var hianyosJelentkezes = new Jelentkezes { JelentkezesId = 7};
            _sut!.ModelState.AddModelError("Helyszin", "Required");
            var result = await _sut!.Post(hianyosJelentkezes);

            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }
        [TestMethod]
        public async Task Put_ExistingId_UpdatesDataAndReturnsOkJelentkezes()
        {
            var options = new DbContextOptionsBuilder<Context>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            await using var context = new Context(options);

            var seedJelentkezes = new Jelentkezes
            {
                JelentkezesId = 8,
                Nev = "Mucsa Johnny Fiú",
                Email = "johnny.mucza@gmail.com",
                Telefon = "+36302515458",
                Lakohely = "Szentgotthárd",
                Pozicio = "raktar",
                Tapasztalat = "igen",
                Bemutatkozas = "I don't speak your language.",
                Letrehozva = new DateTime(2023, 07, 16)
            };
            context.Jelentkezesek.Add(seedJelentkezes);
            await context.SaveChangesAsync();

            var controller = new JelentkezesController(context);

            var frissitettAdatok = new Jelentkezes
            {
                JelentkezesId = 8,
                Nev = "Mucsa Johnny Fiú",
                Email = "johnny.mucsa@gmail.com",
                Telefon = "+36302515457",
                Lakohely = "Szentgotthárd",
                Pozicio = "futar",
                Tapasztalat = "igen",
                Bemutatkozas = "I still don't speak your language.",
                Letrehozva = new DateTime(2023, 07, 21)
            };

            var result = await controller.Put(8, frissitettAdatok);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var visszakapottJelentkezes = okResult!.Value as Jelentkezes;

            Assert.IsNotNull(visszakapottJelentkezes);
            Assert.AreEqual("johnny.mucsa@gmail.com", visszakapottJelentkezes.Email);
            Assert.AreEqual("I still don't speak your language.", visszakapottJelentkezes.Bemutatkozas);
        }

        [TestMethod]
        public async Task Put_NonExistingId_ReturnsNotFoundJelentkezes()
        {
            var frissitettAdatok = new Jelentkezes { JelentkezesId = 999, Nev = "Jelen Ferenc", Email = "jelen.ferenc@gmail.com", Telefon = "+36301234567", Lakohely = "Veszprém", Pozicio = "ugyfelszolgalat", Tapasztalat = "igen", Bemutatkozas = "Szorgoalmasan dolgozok.", Letrehozva = new DateTime(2026, 02, 10) };
            var result = await _sut!.Put(999, frissitettAdatok);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task Delete_ExistingId_RemovesJelentkezesAndReturnsOk()
        {
            var torlendoJelentkezes = new Jelentkezes { JelentkezesId = 10, Nev = "Jelen Ferenc", Email = "jelen.ferenc@gmail.com", Telefon = "+36301234567", Lakohely = "Veszprém", Pozicio = "ugyfelszolgalat", Tapasztalat = "igen", Bemutatkozas = "Szorgoalmasan dolgozok.", Letrehozva = new DateTime(2026, 02, 10) };
            _db!.Context.Jelentkezesek.Add(torlendoJelentkezes);
            await _db.Context.SaveChangesAsync();

            var result = await _sut!.Delete(10);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var letezikE = await _db!.Context.Jelentkezesek.AnyAsync(p => p.JelentkezesId == 10);
            Assert.IsFalse(letezikE);
        }

        [TestMethod]
        public async Task Delete_NonExistingId_ReturnsNotFoundJelentkezes()
        {
            int nemLetezoId = 99;
            var result = await _sut!.Delete(nemLetezoId);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task TestAll_ReturnsOk()
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, "1")
            };
            var identity = new ClaimsIdentity(claims, "TestAuth");
            var claimsPrincipal = new ClaimsPrincipal(identity);
            _sut!.ControllerContext.HttpContext.User = claimsPrincipal;

            _sut!.Request.Scheme = "http";
            _sut.Request.Host = new HostString("localhost");

            #region Create
            var newJelentkezes = new Jelentkezes
            {
                JelentkezesId = 9,
                Nev = "Németné Judit",
                Email = "judit.nemetne@gmail.com",
                Telefon = "+36302345678",
                Lakohely = "Ukk",
                Pozicio = "raktar",
                Tapasztalat = "nem",
                Bemutatkozas = "Első munkám lesz.",
                Letrehozva = new DateTime(2024,04, 04)

            };
            var created = await _sut!.Post(newJelentkezes) as CreatedResult;
            Assert.IsNotNull(created);
            var jelentkezes = created.Value as Jelentkezes;
            Assert.IsNotNull(jelentkezes);
            #endregion

            #region Update
            jelentkezes.Tapasztalat = "igen";
            jelentkezes.Bemutatkozas = "Második munkám";
            var updated = await _sut!.Put(jelentkezes.JelentkezesId, jelentkezes) as OkObjectResult;
            Assert.IsNotNull(updated);
            jelentkezes = updated.Value as Jelentkezes;
            Assert.IsNotNull(jelentkezes);
            #endregion

            #region Get
            var geted = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(geted);
            #endregion

            #region Delete
            var deleted = await _sut!.Delete(jelentkezes.JelentkezesId) as OkObjectResult;
            Assert.IsNotNull(deleted);
            jelentkezes = deleted.Value as Jelentkezes;
            Assert.IsNotNull(jelentkezes);
            #endregion
        }

        [TestMethod]
        public async Task GetJelentezesekList_ReturnsOkEmptyJelentkezesekList()
        {
            _db?.ClearAll();
            var result = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(result);
            var jelentkezesList = result.Value as IEnumerable<Jelentkezes>;
            Assert.IsNotNull(jelentkezesList);
            Assert.AreEqual(0, jelentkezesList.Count());
        }
    }
}
