﻿using FutarkezeloAPI.Controllers;
using FutarkezeloAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace FutarkezeloAPI.Test
{
    [TestClass]
    public sealed class SzallitasControllerTest
    {
        SzallitasController? _sut;
        DbContextHelper? _db;

        [TestInitialize]
        public void Initialize()
        {
            _db = new DbContextHelper();
            _sut = new SzallitasController(_db.CreateDbContext());

            var httpContext = new DefaultHttpContext();
            _sut.ControllerContext = new ControllerContext()
            {
                HttpContext = httpContext
            };
        }

        [TestMethod]
        public async Task GetSzallitasList_ReturnsOkSzallitasList()
        {
            var result = (await _sut!.Get()) as OkObjectResult;
            Assert.IsNotNull(result);
            var szallitasList = result.Value as IEnumerable<Szallitas>;
            Assert.IsNotNull(szallitasList);
            foreach (var szallitas in szallitasList)
            {
                Assert.IsTrue(_db?.SzallitasList
                    .Contains(szallitas, new SzallitasComparer()));
            }
            Assert.AreEqual(szallitasList.Count(), _db?.SzallitasList.Count());
        }

        [TestMethod]
        public async Task GetSzallitasList_ReturnsOkEmptySzallitasList()
        {
            _db?.ClearAll();
            var result = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(result);
            var szallitasList = result.Value as IEnumerable<Szallitas>;
            Assert.IsNotNull(szallitasList);
            Assert.AreEqual(0, szallitasList.Count());
        }

        [TestMethod]
        public async Task GetById_IfIdExists_ReturnsOkSzallitas()
        {
            int existingId = _db!.SzallitasList[index: 0].SzallitasId;
            var result = await _sut!.GetById(existingId);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var returnedSzallitas = okResult!.Value as Szallitas;

            Assert.IsNotNull(returnedSzallitas);
            Assert.AreEqual(existingId, returnedSzallitas.SzallitasId);
        }

        [TestMethod]
        public async Task GetById_IfIdDoesNotExist_ReturnsNotFoundSzallitas()
        {
            int nonExistingId = _db!.SzallitasList.Max(x => x.SzallitasId) + 1;
            var result = await _sut!.GetById(nonExistingId);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task Post_ValidSzallitas_ReturnsCreatedResult()
        {
            var ujSzallitas = new Szallitas {SzallitasId = 999, FutarId = 999, UtvonalId = 999, Allapot = "mindjárt", Idopont = DateTime.Now };
            var result = await _sut!.Post(ujSzallitas);
            Assert.IsInstanceOfType(result, typeof(CreatedResult));
             
            var createdResult = result as CreatedResult;
            Assert.IsNotNull(createdResult);
        }
        [TestMethod]
        public async Task Post_InvalidSzallitas_ReturnsBadRequest()
        {
            var hianyosSzallitas = new Szallitas { FutarId = 1, UtvonalId = 1 };
            _sut!.ModelState.AddModelError("Allapot", "Required");
            var result = await _sut!.Post(hianyosSzallitas);

            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }
        [TestMethod]
        public async Task Put_ExistingId_UpdatesDataAndReturnsOkSzallitas()
        {
            var options = new DbContextOptionsBuilder<Context>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            await using var context = new Context(options);

            var seedSzallitas = new Szallitas
            {
                SzallitasId = 1,
                UtvonalId = 1,
                FutarId = 1,
                Idopont = DateTime.Now,
                Allapot = "Feldolgozás alatt"
            };
            context.Szallitasok.Add(seedSzallitas);
            await context.SaveChangesAsync();

            var controller = new SzallitasController(context);

            var frissitettAdatok = new Szallitas
            {
                SzallitasId = 1,
                UtvonalId = 1,
                FutarId = 1,
                Idopont = DateTime.Now,
                Allapot = "Kézbesítve"
            };

            var result = await controller.Put(1, frissitettAdatok);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var visszakapottSzallitas = okResult!.Value as Szallitas;

            Assert.IsNotNull(visszakapottSzallitas);
            Assert.AreEqual("Kézbesítve", visszakapottSzallitas.Allapot);

        }

        [TestMethod]
        public async Task Put_NonExistingId_ReturnsNotFoundSzallitas()
        {
            var frissitettAdatok = new Szallitas { SzallitasId = 998, FutarId = 998, UtvonalId = 998, Allapot = "Elrabolták", Idopont = DateTime.Now};
            var result = await _sut!.Put(998, frissitettAdatok);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task Delete_ExistingId_RemovesSzallitasAndReturnsOk()
        {
            var torlendoSzallitas = new Szallitas {SzallitasId = 10, FutarId = 1, UtvonalId = 1, Idopont = DateTime.Now, Allapot = "Felrobbant" };
            _db!.Context.Szallitasok.Add(torlendoSzallitas);
            await _db.Context.SaveChangesAsync();

            var result = await _sut!.Delete(10);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var visszakapottSzallitas = okResult!.Value as Szallitas;

            Assert.IsNotNull(visszakapottSzallitas);
            Assert.AreEqual(10, visszakapottSzallitas.SzallitasId);

            var letezikE = await _db.Context.Szallitasok.AnyAsync(p => p.SzallitasId == 10);
            Assert.IsFalse(letezikE);
        }

        [TestMethod]
        public async Task Delete_NonExistingId_ReturnsNotFoundSzallitas()
        {
            int nemLetezoId = 99;
            var result = await _sut!.Delete(nemLetezoId);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task TestAll_ReturnsOk()
        {
            #region Create
            var newSzallitas = new Szallitas
            {
                SzallitasId = 10,
                FutarId = 15,
                UtvonalId = 20,
                Allapot = "Folyamatban",
                Idopont = new DateTime(2026, 06, 23)
            };
            var created = await _sut!.Post(newSzallitas) as CreatedResult;
            Assert.IsNotNull(created);
            var szallitas = created.Value as Szallitas;
            Assert.IsNotNull(szallitas);
            #endregion

            #region Update
            szallitas.Allapot = "Törölve";
            szallitas.Idopont = new DateTime(2026, 05, 27);
            var updated = await _sut!.Put(szallitas.SzallitasId, szallitas) as OkObjectResult;
            Assert.IsNotNull(updated);
            szallitas = updated.Value as Szallitas;
            Assert.IsNotNull(szallitas);
            #endregion

            #region Get
            var geted = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(geted);
            #endregion

            #region Delete
            var deleted = await _sut!.Delete(szallitas.SzallitasId) as OkObjectResult;
            Assert.IsNotNull(deleted);
            szallitas = deleted.Value as Szallitas;
            Assert.IsNotNull(szallitas);
            #endregion
        }
    }
}
