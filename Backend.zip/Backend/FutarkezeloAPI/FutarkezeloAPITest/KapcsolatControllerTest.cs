﻿using FutarkezeloAPI.Controllers;
using FutarkezeloAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace FutarkezeloAPI.Test
{
    [TestClass]
    public sealed class KapcsolatControllerTest
    {
        KapcsolatController? _sut;
        DbContextHelper? _db;

        [TestInitialize]
        public void Initialize()
        {
            _db = new DbContextHelper();
            _sut = new KapcsolatController(_db.CreateDbContext());

            var httpContext = new DefaultHttpContext();
            _sut.ControllerContext = new ControllerContext()
            {
                HttpContext = httpContext
            };
        }

        [TestMethod]
        public async Task GetKapcsolatList_ReturnsOkKapcsolatList()
        {
            var result = (await _sut!.Get()) as OkObjectResult;
            Assert.IsNotNull(result);
            var kapcsolatList = result.Value as IEnumerable<Kapcsolat>;
            Assert.IsNotNull(kapcsolatList);
            foreach (var kapcsolat in kapcsolatList)
            {
                Assert.IsTrue(_db?.KapcsolatList
                    .Contains(kapcsolat, new KapcsolatComparer()));
            }
            Assert.AreEqual(kapcsolatList.Count(), _db?.KapcsolatList.Count());
        }

        [TestMethod]
        public async Task GetKapcsolatList_ReturnsOkEmptyKapcsolatList()
        {
            _db?.ClearAll();
            var result = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(result);
            var kapcsolatList = result.Value as IEnumerable<Kapcsolat>;
            Assert.IsNotNull(kapcsolatList);
            Assert.AreEqual(0, kapcsolatList.Count());
        }

        [TestMethod]
        public async Task GetById_IfIdExists_ReturnsOkKapcsolat()
        {
            int existingId = _db!.KapcsolatList[index: 0].KapcsolatId;
            var result = await _sut!.GetById(existingId);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var returnedKapcsolat = okResult!.Value as Kapcsolat;

            Assert.IsNotNull(returnedKapcsolat);
            Assert.AreEqual(existingId, returnedKapcsolat.KapcsolatId);
        }

        [TestMethod]
        public async Task GetById_IfIdDoesNotExist_ReturnsNotFoundKapcsolat()
        {
            int nonExistingId = _db!.KapcsolatList.Max(x => x.KapcsolatId) + 1;
            var result = await _sut!.GetById(nonExistingId);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task Post_ValidKapcsolat_ReturnsCreatedResult()
        {
            var ujKapcsolat = new Kapcsolat { FelhasznaloId = 999, Nev = "Elek", Email = "teszt@gmail.com", KapcsolatId = 999, LetrehozasDatuma = new DateTime(), Uzenet = "dghrgh", Tema = "", Telefon = "zhzth"};
            var result = await _sut!.Post(ujKapcsolat);
            Assert.IsInstanceOfType(result, typeof(CreatedResult));

            var createdResult = result as CreatedResult;
            Assert.IsNotNull(createdResult);
        }
        [TestMethod]
        public async Task Post_InvalidKapcsolat_ReturnsBadRequest()
        {
            var hianyosKapcsolat = new Kapcsolat { };
            _sut!.ModelState.AddModelError("Nev", "Required");
            var result = await _sut!.Post(hianyosKapcsolat);

            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }
        [TestMethod]
        public async Task Put_ExistingId_UpdatesDataAndReturnsOkKapcsolat() 
        {
            var options = new DbContextOptionsBuilder<Context>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            await using var context = new Context(options);

            var seedKapcsolat = new Kapcsolat
            {
                FelhasznaloId = 1,
                Nev = "Sanyi",
                Email = "sanyi@gmail.com",
                KapcsolatId = 1,
                Telefon = "",
                Tema = "",
                Uzenet = "",
                LetrehozasDatuma = new DateTime()
            };
            context.Kapcsolatok.Add(seedKapcsolat);
            await context.SaveChangesAsync();

            var controller = new KapcsolatController(context);

            var frissitettAdatok = new Kapcsolat
            {
                FelhasznaloId = 1,
                Nev = "Pista",
                Email = "pista@gmail.com",
                KapcsolatId = 1,
                Telefon = "+36209475847",
                Tema = "Szia",
                Uzenet = "Szia",
                LetrehozasDatuma = new DateTime(1492)
            };

            var result = await controller.Put(1, frissitettAdatok);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var visszakapottKapcsolat = okResult!.Value as Kapcsolat;

            Assert.IsNotNull(visszakapottKapcsolat);
            Assert.AreEqual("Pista", visszakapottKapcsolat.Nev);
            Assert.AreEqual("pista@gmail.com", visszakapottKapcsolat.Email);

        }

        [TestMethod]
        public async Task Put_NonExistingId_ReturnsNotFoundKapcsolat()
        {
            var frissitettAdatok = new Kapcsolat { FelhasznaloId = 1, Nev = "Pista", Email = "teszt@gmail.com", KapcsolatId = 999, LetrehozasDatuma = new DateTime(), Uzenet = "", Tema = "", Telefon = "" };
            var result = await _sut!.Put(999, frissitettAdatok);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task Delete_ExistingId_RemovesKapcsolatAndReturnsOk()
        {
            var torlendoKapcsolat = new Kapcsolat { FelhasznaloId = 1, Nev = "Pista", Email = "teszt@gmail.com", KapcsolatId = 999, LetrehozasDatuma = new DateTime(), Uzenet = "", Tema = "", Telefon = "" };
            _db!.Context.Kapcsolatok.Add(torlendoKapcsolat);
            await _db.Context.SaveChangesAsync();

            var result = await _sut!.Delete(999);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var visszakapottKapcsolat = okResult!.Value as Kapcsolat;

            Assert.IsNotNull(visszakapottKapcsolat);
            Assert.AreEqual(999, visszakapottKapcsolat.KapcsolatId);

            var letezikE = await _db.Context.Kapcsolatok.AnyAsync(p => p.KapcsolatId == 999);
            Assert.IsFalse(letezikE);
        }

        [TestMethod]
        public async Task Delete_NonExistingId_ReturnsNotFoundKapcsolat()
        {
            int nemLetezoId = 99;
            var result = await _sut!.Delete(nemLetezoId);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task TestAll_ReturnsOk()
        {
            #region Create
            var newKapcsolat = new Kapcsolat
            {
                FelhasznaloId = 1,
                Nev = "Pista",
                Email = "pista@gmail.com",
                KapcsolatId = 999,
                Telefon = "+36209475847",
                Tema = "Szia",
                Uzenet = "Szia",
                LetrehozasDatuma = new DateTime(1492)
            };
            var created = await _sut!.Post(newKapcsolat) as CreatedResult;
            Assert.IsNotNull(created);
            var kapcsolat = created.Value as Kapcsolat;
            Assert.IsNotNull(kapcsolat);
            #endregion

            #region Update
            kapcsolat.Email = "sanyi@gmail.com";
            kapcsolat.Nev = "Nagy Sanyi";
            var updated = await _sut!.Put(kapcsolat.KapcsolatId, kapcsolat) as OkObjectResult;
            Assert.IsNotNull(updated);
            kapcsolat = updated.Value as Kapcsolat;
            Assert.IsNotNull(kapcsolat);
            #endregion

            #region Get
            var geted = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(geted);
            #endregion

            #region Delete
            var deleted = await _sut!.Delete(kapcsolat.KapcsolatId) as OkObjectResult;
            Assert.IsNotNull(deleted);
            kapcsolat = deleted.Value as Kapcsolat;
            Assert.IsNotNull(kapcsolat);
            #endregion
        }
    }
}
