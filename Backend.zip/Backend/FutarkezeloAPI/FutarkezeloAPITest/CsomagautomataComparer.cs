﻿using FutarkezeloAPI.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FutarkezeloAPI.Test
{
    internal class CsomagautomataComparer : IEqualityComparer<Csomagautomata>
    {
        public bool Equals(Csomagautomata? x, Csomagautomata? y)
        {
            return x == null && y == null ||
                x?.CsomagautomataId == y?.CsomagautomataId &&
                x?.Helyszin == y?.Helyszin &&
                x?.Nyitvatartas == y?.Nyitvatartas &&
                x?.UtvonalId == y?.UtvonalId;
        }

        public int GetHashCode([DisallowNull] Csomagautomata obj) => obj.CsomagautomataId;
    }
}
