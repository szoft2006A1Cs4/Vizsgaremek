﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FutarkezeloAPI.Model;

namespace FutarkezeloAPI.Test
{
    internal class SzallitasComparer : IEqualityComparer<Szallitas>
    {
        public bool Equals(Szallitas? x, Szallitas? y)
        {
            return x == null && y == null ||
                x?.SzallitasId == y?.SzallitasId &&
                x?.FutarId == y?.FutarId &&
                x?.UtvonalId == y?.UtvonalId &&
                x?.Idopont == y?.Idopont &&
                x?.Allapot == y?.Allapot;
        }

        public int GetHashCode([DisallowNull] Szallitas obj) => obj.SzallitasId;
    }
}
