﻿using FutarkezeloAPI.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FutarkezeloAPI.Test
{
    internal class JelentkezesComparer : IEqualityComparer<Jelentkezes>
    {
        public bool Equals(Jelentkezes? x, Jelentkezes? y)
        {
            return x == null && y == null ||
                x?.JelentkezesId == y?.JelentkezesId &&
                x?.Nev == y?.Nev &&
                x?.Telefon == y?.Telefon &&
                x?.Email == y?.Email &&
                x?.Tapasztalat == y?.Tapasztalat &&
                x?.Pozicio == y?.Pozicio &&
                x?.Lakohely == y?.Lakohely;
        }

        public int GetHashCode([DisallowNull] Jelentkezes obj) => obj.JelentkezesId;
    }
}
