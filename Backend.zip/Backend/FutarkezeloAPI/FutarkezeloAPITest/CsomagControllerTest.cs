﻿using FutarkezeloAPI.Controllers;
using FutarkezeloAPI.Model;
using Microsoft.AspNetCore.Mvc;
using System.Numerics;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;

namespace FutarkezeloAPI.Test
{
    [TestClass]
    public sealed class CsomagControllerTest
    {
        CsomagController? _sut;
        DbContextHelper? _db;

        [TestInitialize]
        public void Initialize()
        {
            _db = new DbContextHelper();
            _sut = new CsomagController(_db.CreateDbContext());
            var httpContext = new DefaultHttpContext();
            _sut.ControllerContext = new ControllerContext()
            {
                HttpContext = httpContext
            };
        }

        [TestMethod]
        public async Task GetCsomagList_ReturnsOkCsomagList()
        {
            var result = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(result);
            var csomagList = result.Value as IEnumerable<Csomag>;
            Assert.IsNotNull(csomagList);
            foreach (var csomag in csomagList)
            {
                Assert.IsTrue(_db?.CsomagList
                    .Contains(csomag, new CsomagComparer()));
            }
            Assert.AreEqual(csomagList.Count(), _db?.CsomagList.Count());
        }

        [TestMethod]
        public async Task GetCsomagList_ReturnsOkEmptyCsomagList()
        {
            _db?.ClearAll();
            var result = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(result);
            var csomagList = result.Value as IEnumerable<Csomag>;
            Assert.IsNotNull(csomagList);
            Assert.AreEqual(0, csomagList.Count());
        }
        [TestMethod]
        public async Task GetById_IfIdExists_ReturnsOkCsomag()
        {
            int existingId = _db!.CsomagList[index: 0].CsomagId;
            var result = await _sut!.GetById(existingId);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var returnedCsomag = okResult!.Value as Csomag;

            Assert.IsNotNull(returnedCsomag);
            Assert.AreEqual(existingId, returnedCsomag.CsomagId);
        }

        [TestMethod]
        public async Task GetById_IfIdDoesNotExist_ReturnsNotFoundCsomag()
        {
            int nonExistingId = _db!.CsomagList.Max(x => x.CsomagId) + 1; 
            var result = await _sut!.GetById(nonExistingId);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task Post_ValidCsomag_ReturnsCreatedResult()
        {
            var ujCsomag = new Csomag {CsomagId = 999, Leiras = "Uj csomag", Meret = "M", Suly = 2, CsomagautomataId = 5, FelhasznaloId = 999, CimzettNev = "Kis pista", CimzettTelefonszam = "+36701234567", FeladoEmail = "kovacs.viktor@gmail.com", FeladoNev = "Komlósi Máté", FeladoTelefonszam = "+36701231234", SzallitasiDij = 231, Torekeny = true , CimzettEmail = "email@gmail.com"};
            var result = await _sut!.Post(ujCsomag);
            Assert.IsInstanceOfType(result, typeof(CreatedResult));

            var createdResult = result as CreatedResult;
            Assert.IsNotNull(createdResult);
        }
        [TestMethod]
        public async Task Post_InvalidCsomag_ReturnsBadRequest()
        {
            var hianyosCsomag = new Csomag {CsomagautomataId = 1, FelhasznaloId = 1};
            _sut!.ModelState.AddModelError("Leiras", "Required");
            var result = await _sut!.Post(hianyosCsomag);

            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }
        [TestMethod]
        public async Task Put_ExistingId_UpdatesDataAndReturnsOkCsomag()
        {
            var options = new DbContextOptionsBuilder<Context>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            await using var context = new Context(options);

            var seedCsomag = new Csomag
            {
                CsomagId = 1,
                Leiras = "Eredeti",
                Meret = "Kicsi",
                Suly = 5,
                CsomagautomataId = 30,
                FelhasznaloId = 52
            };
            context.Csomagok.Add(seedCsomag);
            await context.SaveChangesAsync();

            var controller = new CsomagController(context);

            var frissitettAdatok = new Csomag
            {
                CsomagId = 1,
                Leiras = "Frissített",
                Meret = "Nagy",
                Suly = 15,
                CsomagautomataId = 30,
                FelhasznaloId = 52
            };

            var result = await controller.Put(1, frissitettAdatok);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var visszakapottCsomag = okResult!.Value as Csomag;

            Assert.IsNotNull(visszakapottCsomag);
            Assert.AreEqual("Frissített", visszakapottCsomag.Leiras);
            Assert.AreEqual(15, visszakapottCsomag.Suly);

        }

        [TestMethod]
        public async Task Put_NonExistingId_ReturnsNotFoundCsomag()
        {
            var frissitettAdatok = new Csomag { CsomagId = 999, Leiras = "Hógömb", Meret = "Kicsi", Suly = 1, CsomagautomataId = 50, FelhasznaloId = 30 };
            var result = await _sut!.Put(999, frissitettAdatok);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task Delete_ExistingId_RemovesCsomagAndReturnsOk()
        {
            var torlendoCsomag = new Csomag { CsomagId = 10, Leiras = "Törlendő Csomag", Meret = "Kicsi", Suly = 2, CsomagautomataId = 1, FelhasznaloId = 1 };
            _db!.Context.Csomagok.Add(torlendoCsomag);
            await _db.Context.SaveChangesAsync();

            var result = await _sut!.Delete(10);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var visszakapottCsomag = okResult!.Value as Csomag;

            Assert.IsNotNull(visszakapottCsomag);
            Assert.AreEqual(10, visszakapottCsomag.CsomagId);

            var letezikE = await _db.Context.Csomagok.AnyAsync(p => p.CsomagId == 10);
            Assert.IsFalse(letezikE);
        }

        [TestMethod]
        public async Task Delete_NonExistingId_ReturnsNotFoundCsomag()
        {
            int nemLetezoId = 99;
            var result = await _sut!.Delete(nemLetezoId);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task TestAll_ReturnsOk()
        {
            _sut!.Request.Scheme = "http";
            _sut.Request.Host = new HostString("localhost");
            #region Create
            var newCsomag = new Csomag
            {
                CsomagId = 996,
                Leiras = "Búza finom liszt",
                CsomagautomataId = 4,
                FelhasznaloId = 10,
                Meret = "L",
                Suly = 15,
                CimzettNev = "Molnár Katalin",
                CimzettTelefonszam = "+3620111122",
                CimzettEmail = "katalin.molnar@gmail.com",
                FeladoEmail = "andras.farkas@gmail.com",
                FeladoNev = "Farkas András",
                FeladoTelefonszam = "+3670555123",
                SzallitasiDij = 499,
                Torekeny = true
                
            };
            var created = await _sut!.Post(newCsomag) as CreatedResult;
            Assert.IsNotNull(created);

            var response = created?.Value as CsomagPostResponse;
            var csomag = response?.csomag;

            Assert.IsNotNull(csomag);
            #endregion

            #region Update
            csomag.Leiras = "Tavi Rózsa";
            csomag.Suly = 21;
            var updated = await _sut!.Put(csomag.CsomagId, csomag) as OkObjectResult;
            Assert.IsNotNull(updated);
            csomag = updated.Value as Csomag;
            Assert.IsNotNull(csomag);
            #endregion

            #region Get
            var geted = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(geted);
            #endregion

            #region Delete
            var deleted = await _sut!.Delete(csomag.CsomagId) as OkObjectResult;
            Assert.IsNotNull(deleted);
            csomag = deleted.Value as Csomag;
            Assert.IsNotNull(csomag);
            #endregion
        }
    }
}
