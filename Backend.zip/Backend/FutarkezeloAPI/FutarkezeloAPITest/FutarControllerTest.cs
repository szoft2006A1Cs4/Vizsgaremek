﻿using FutarkezeloAPI.Controllers;
using FutarkezeloAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace FutarkezeloAPI.Test
{
    [TestClass]
    public sealed class FutarControllerTest
    {
        FutarController? _sut;
        DbContextHelper? _db;

        [TestInitialize]
        public void Initialize()
        {
            _db = new DbContextHelper();
            _sut = new FutarController(_db.CreateDbContext());

            var httpContext = new DefaultHttpContext();
            _sut.ControllerContext = new ControllerContext()
            {
                HttpContext = httpContext
            };
        }

        [TestMethod]
        public async Task GetFutarList_ReturnsOkFutarList()
        {
            var result = (await _sut!.Get()) as OkObjectResult;
            Assert.IsNotNull(result);
            var futarList = result.Value as IEnumerable<Futar>;
            Assert.IsNotNull(futarList);
            foreach (var futar in futarList)
            {
                Assert.IsTrue(_db?.FutarList
                    .Contains(futar, new FutarComparer()));
            }
            Assert.AreEqual(futarList.Count(), _db?.FutarList.Count());
        }

        [TestMethod]
        public async Task GetFutarList_ReturnsOkEmptyFutarList()
        {
            _db?.ClearAll();
            var result = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(result);
            var futarList = result.Value as IEnumerable<Futar>;
            Assert.IsNotNull(futarList);
            Assert.AreEqual(0, futarList.Count());
        }

        [TestMethod]
        public async Task GetById_IfIdExists_ReturnsOkFutar()
        {
            int existingId = _db!.FutarList[index: 0].FutarId;
            var result = await _sut!.GetById(existingId);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var returnedFutar = okResult!.Value as Futar;

            Assert.IsNotNull(returnedFutar);
            Assert.AreEqual(existingId, returnedFutar.FutarId);
        }

        [TestMethod]
        public async Task GetById_IfIdDoesNotExist_ReturnsNotFoundFutar()
        {
            int nonExistingId = _db!.FutarList.Max(x => x.FutarId) + 1;
            var result = await _sut!.GetById(nonExistingId);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task Post_ValidFutar_ReturnsCreatedResult()
        {
            var ujFutar = new Futar { FutarId = 999, Nev = "Jóska", Elerhetoseg = "+3612867354", Jogositvany_Tipus = "B" , Munka_Kezdese = DateTime.Now ,JarmuId = 999  };
            var result = await _sut!.Post(ujFutar);
            Assert.IsInstanceOfType(result, typeof(CreatedResult));

            var createdResult = result as CreatedResult;
            Assert.IsNotNull(createdResult);
        }
        [TestMethod]
        public async Task Post_InvalidFutar_ReturnsBadRequest()
        {
            var hianyosFutar = new Futar { JarmuId = 1};
            _sut!.ModelState.AddModelError("Nev", "Required");
            var result = await _sut!.Post(hianyosFutar);

            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }
        [TestMethod]
        public async Task Put_ExistingId_UpdatesDataAndReturnsOkFutar() 
        {
            var options = new DbContextOptionsBuilder<Context>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            await using var context = new Context(options);

            var seedFutar = new Futar
            {
                FutarId = 1,
                Nev = "Sanyi",
                Elerhetoseg = "+0612986731",
                Jogositvany_Tipus = "B",
                Munka_Kezdese = DateTime.Now,
                JarmuId = 1
            };
            context.Futarok.Add(seedFutar);
            await context.SaveChangesAsync();

            var controller = new FutarController(context);

            var frissitettAdatok = new Futar
            {
                FutarId = 1,
                Nev = "Kolompér",
                Elerhetoseg = "+061275731",
                Jogositvany_Tipus = "C",
                Munka_Kezdese = DateTime.Now,
                JarmuId = 1
            };

            var result = await controller.Put(1, frissitettAdatok);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var visszakapottFutar = okResult!.Value as Futar;

            Assert.IsNotNull(visszakapottFutar);
            Assert.AreEqual("Kolompér", visszakapottFutar.Nev);
            Assert.AreEqual("+061275731", visszakapottFutar.Elerhetoseg);

        }

        [TestMethod]
        public async Task Put_NonExistingId_ReturnsNotFoundFutar()
        {
            var frissitettAdatok = new Futar { FutarId = 999, Nev = "Jóska", Elerhetoseg = "+3612867354", Jogositvany_Tipus = "B", Munka_Kezdese = DateTime.Now, JarmuId = 999 };
            var result = await _sut!.Put(999, frissitettAdatok);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task Delete_ExistingId_RemovesFutarAndReturnsOk()
        {
            var torlendoCsomag = new Futar { FutarId = 10, Nev = "Jóska", Elerhetoseg = "+3612867354", Jogositvany_Tipus = "B", Munka_Kezdese = DateTime.Now, JarmuId = 10 };
            _db!.Context.Futarok.Add(torlendoCsomag);
            await _db.Context.SaveChangesAsync();

            var result = await _sut!.Delete(10);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));

            var okResult = result as OkObjectResult;
            var visszakapottFutar = okResult!.Value as Futar;

            Assert.IsNotNull(visszakapottFutar);
            Assert.AreEqual(10, visszakapottFutar.FutarId);

            var letezikE = await _db.Context.Futarok.AnyAsync(p => p.FutarId == 10);
            Assert.IsFalse(letezikE);
        }

        [TestMethod]
        public async Task Delete_NonExistingId_ReturnsNotFoundFutar()
        {
            int nemLetezoId = 99;
            var result = await _sut!.Delete(nemLetezoId);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }
        [TestMethod]
        public async Task TestAll_ReturnsOk()
        {
            #region Create
            var newFutar = new Futar 
            {
                FutarId = 10,
                JarmuId = 10,
                Elerhetoseg = "+987654321",
                Jogositvany_Tipus = "B",
                Nev = "Nemer Eszti",
                Munka_Kezdese = new DateTime(2021, 05, 11)

            };
            var created = await _sut!.Post(newFutar) as CreatedResult;
            Assert.IsNotNull(created);
            var futar = created.Value as Futar;
            Assert.IsNotNull(futar);
            #endregion

            #region Update
            futar.Elerhetoseg = "+998877445";
            futar.Jogositvany_Tipus = "C";
            var updated = await _sut!.Put(futar.FutarId, futar) as OkObjectResult;
            Assert.IsNotNull(updated);
            futar = updated.Value as Futar;
            Assert.IsNotNull(futar);
            #endregion

            #region Get
            var geted = await _sut!.Get() as OkObjectResult;
            Assert.IsNotNull(geted);
            #endregion

            #region Delete
            var deleted = await _sut!.Delete(futar.FutarId) as OkObjectResult;
            Assert.IsNotNull(deleted);
            futar = deleted.Value as Futar;
            Assert.IsNotNull(futar);
            #endregion
        }
    }
}
