﻿using FutarkezeloAPI.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Options;
using SQLitePCL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text; 
using System.Threading.Tasks;

namespace FutarkezeloAPI.Test
{
    internal class DbContextHelper
    {
        private Context? _context = null;
        public Context Context => _context!;

        public List<Csomag> CsomagList =
            [
                new Csomag { CsomagId = 1, Leiras = "Törékeny", Meret = "Hatalmas", Suly = 20, CsomagautomataId = 1, FelhasznaloId = 1},
                new Csomag { CsomagId = 2, Leiras = "Elektronikus cikk", Meret = "Közepes", Suly = 8, CsomagautomataId = 2, FelhasznaloId = 2},
                new Csomag { CsomagId = 3, Leiras = "Törékeny", Meret = "Kicsi", Suly = 1, CsomagautomataId = 3, FelhasznaloId = 3},
                new Csomag { CsomagId = 4, Leiras = "", Meret = "közepes", Suly = 5, CsomagautomataId = 4, FelhasznaloId = 4},
                new Csomag { CsomagId = 5, Leiras = "Zseblámpa", Meret = "Kicsi", Suly = 3.13, CsomagautomataId = 5, FelhasznaloId = 5 }
            ];
        public List<Csomagautomata> CsomagautomataList = 
            [
                new Csomagautomata {CsomagautomataId = 1, Helyszin = "Budapest, Deák tér 1.", Nyitvatartas = "0-24", UtvonalId = 1},
                new Csomagautomata {CsomagautomataId = 2, Helyszin = "Chichago utcáin", Nyitvatartas = "null-huszonnégy", UtvonalId = 2},
                new Csomagautomata {CsomagautomataId = 3, Helyszin = "Szombathely, Király utca 3.", Nyitvatartas = "null-huszonnégy", UtvonalId = 3},
                new Csomagautomata {CsomagautomataId = 4, Helyszin = "Zalaegerszeg, Petőfi Sándor utca 25.", Nyitvatartas = "null-huszonnégy", UtvonalId = 4},
                new Csomagautomata {CsomagautomataId = 5, Helyszin = "Budapest, Nagy Imre tér 7", Nyitvatartas = "null-huszonnégy", UtvonalId = 5}
            ];
        public List<Felhasznalo> FelhasznaloList =
            [
                new Felhasznalo {FelhasznaloId = 1, Nev = "Gipsz Jakab", Email = "gibsz.jakab@gmail.com", Jogosultsag = "User", Telefonszam = "+3123456789", Jelszo = "Bala2000!"},
                new Felhasznalo {FelhasznaloId = 2, Nev = "Para Zita", Email = "para.zita@gmail.com", Jogosultsag = "Super-User", Telefonszam = "+72536147"},
                new Felhasznalo {FelhasznaloId = 3, Nev = "Lekv Áron", Email = "lekv.aron@gmail.com", Jogosultsag = "Admin", Telefonszam = "+85653212"},
                new Felhasznalo {FelhasznaloId = 4, Nev = "Abrosz Tisztakosz", Email = "abrosz.tisztakosz@gmail.com", Jogosultsag = "User", Telefonszam = "+16248715"},
                new Felhasznalo {FelhasznaloId = 5, Nev = "Britni Szpírsz", Email = "britni.szpirisz@gmail.com", Jogosultsag = "Admin", Telefonszam = "+26646536"},
                new Felhasznalo {FelhasznaloId = 6, Nev = "Boro Zoltán", Email = "boro.zoltan@gmail.com", Jogosultsag = "Admin", Telefonszam = "+98291537"}
            ];
        public List<Futar> FutarList = 
            [
                new Futar {FutarId = 1, Nev = "Gagyi Mami", Elerhetoseg = "+32336541", Jogositvany_Tipus = "B", Munka_Kezdese = new DateTime(2024, 11, 24), JarmuId = 1},
                new Futar {FutarId = 2, Nev = "Viz Elek", Elerhetoseg = "+21547896", Jogositvany_Tipus = "C", Munka_Kezdese = new DateTime(2015, 06, 19), JarmuId = 2},
                new Futar {FutarId = 3, Nev = "Hát Izsák", Elerhetoseg = "+789562191", Jogositvany_Tipus = "A", Munka_Kezdese = new DateTime(2022, 04, 10), JarmuId = 3},
                new Futar {FutarId = 4, Nev = "Kispál Inka", Elerhetoseg = "+74562133", Jogositvany_Tipus = "C", Munka_Kezdese = new DateTime(2020, 11, 01), JarmuId = 4},
                new Futar {FutarId = 5, Nev = "Bor Ivó", Elerhetoseg = "+85321467", Jogositvany_Tipus = "A", Munka_Kezdese = new DateTime(2016, 04, 03), JarmuId = 5},
                new Futar {FutarId = 6, Nev = "Jó Ivó", Elerhetoseg = "+99856231", Jogositvany_Tipus = "B", Munka_Kezdese = new DateTime(2018, 03, 10), JarmuId = 6}
            ];
        public List<Jarmu> JarmuList =
            [
                new Jarmu {JarmuId = 1,Rendszam = "RTA-123", Tipus = "Személyautó", Kapacitas_Kg = 250, Allapot = "Szervízben"},
                new Jarmu {JarmuId = 2,Rendszam = "AAR-223", Tipus = "Kisteherautó", Kapacitas_Kg = 250, Allapot = "Szabad"},
                new Jarmu {JarmuId = 3,Rendszam = "ITE-888", Tipus = "Személyautó", Kapacitas_Kg = 250, Allapot = "Használatban"},
                new Jarmu {JarmuId = 4,Rendszam = "STH-311", Tipus = "Gőzmozdony", Kapacitas_Kg = 250, Allapot = "Nyugdíjba vonult"},
                new Jarmu {JarmuId = 5,Rendszam = "BA-BA-13", Tipus = "Furgon", Kapacitas_Kg = 650, Allapot = "Használatban"}

            ];
        public List<Szallitas> SzallitasList =
            [
                new Szallitas {SzallitasId = 1, FutarId = 1, UtvonalId = 1, Idopont = new DateTime(2026, 04, 10, 12, 30, 0), Allapot = "Törölve"},
                new Szallitas {SzallitasId = 2, FutarId = 2, UtvonalId = 2, Idopont = new DateTime(2026, 02, 03, 17, 45, 0), Allapot = "Folyamatban"},
                new Szallitas {SzallitasId = 3, FutarId = 3, UtvonalId = 3, Idopont = new DateTime(2025, 09, 21, 15, 30, 0), Allapot = "Teljesítve"},
                new Szallitas {SzallitasId = 4, FutarId = 4, UtvonalId = 4, Idopont = new DateTime(2025, 08, 04, 9, 30, 0), Allapot = "Törölve"},
                new Szallitas {SzallitasId = 5, FutarId = 5, UtvonalId = 5, Idopont = new DateTime(2025, 12, 18, 16, 0, 0), Allapot = "Teljesítve"}
            ];
        public List<Utvonal> UtvonalList =
            [
                new Utvonal {UtvonalId = 1, KezdoPont = "Budapest", Vegpont = "Sárvár", Hossz = 200, Forgalom = "közepes"},
                new Utvonal {UtvonalId = 2, KezdoPont = "Debrecen", Vegpont = "Szombathely", Hossz = 220, Forgalom = "erős"},
                new Utvonal {UtvonalId = 3, KezdoPont = "Győr", Vegpont = "Sárvár", Hossz = 120, Forgalom = "közepes"},
                new Utvonal {UtvonalId = 4, KezdoPont = "Szeged", Vegpont = "Budapest", Hossz = 78, Forgalom = "erős"},
                new Utvonal {UtvonalId = 5, KezdoPont = "Pécs", Vegpont = "Zalaegerszeg", Hossz = 320, Forgalom = "enyhe"}
            ];

        public List<Jelentkezes> JelentkezesList =
            [
                new Jelentkezes {JelentkezesId = 1, Nev = "Nagy Panna", Email = "nagy.panna@gmail.com", Telefon = "+36305442632", Lakohely = "Körmend", Pozicio = "raktar", Tapasztalat = "igen", Bemutatkozas = "Sokat dolgozok, sosem fáradok el.", Letrehozva = new DateTime(2025, 03, 14)},
                new Jelentkezes {JelentkezesId = 2, Nev = "Kiss Pista", Email = "pista.kiss@gmail.com", Telefon = "+36306548875", Lakohely = "Nagykanizsa", Pozicio = "raktar", Tapasztalat = "igen", Bemutatkozas = "Nem szeretek dolgozni de kell a pénz.", Letrehozva = new DateTime(2023, 10, 19)},
                new Jelentkezes {JelentkezesId = 3, Nev = "Édes Bala", Email = "bala.edes@gmail.com", Telefon = "+36202020222", Lakohely = "Nemeskolta", Pozicio = "admin", Tapasztalat = "nem", Bemutatkozas = "Nagyon szeretem a palacsintát", Letrehozva = new DateTime(2026, 01, 25)},
                new Jelentkezes {JelentkezesId = 4, Nev = "kovács Gyuri", Email = "gyuri.kovacs@gmail.com", Telefon = "+36301014725", Lakohely = "Budapest", Pozicio = "futar", Tapasztalat = "nem", Bemutatkozas = "Szeretek vezetni és emberekkel beszélni.", Letrehozva = new DateTime(2022, 11, 03)},
                new Jelentkezes {JelentkezesId = 5, Nev = "Ducsai Piroska", Email = "piroska.ducsai@gmail.com", Telefon = "+3630112233456", Lakohely = "Bükk", Pozicio = "ugyfelszolgalat", Tapasztalat = "nem", Bemutatkozas = "Én nem tudom, hogy mért vagyok itt.", Letrehozva = new DateTime(2021, 09, 01)},
            ];

        public List<Kapcsolat> KapcsolatList =
           [
               new Kapcsolat {KapcsolatId = 1, Email = "nagy.panna@gmail.com", FelhasznaloId = 1, LetrehozasDatuma = new DateTime(2025, 02, 2), Nev = "Nagy Panna", Telefon = "36305442632", Tema = "panasz", Uzenet = "Nem tetszik az oldal kinézete."},
                new Kapcsolat {KapcsolatId = 2, Email = "pista.kiss@gmail.com", FelhasznaloId = 2, LetrehozasDatuma = new DateTime(2025, 02, 6), Nev = "Kiss Pista", Telefon = "36306548875", Tema = "megfigyelés", Uzenet = "2 percet késett a futár, szeretném ha kirúgnák."},
                new Kapcsolat {KapcsolatId = 3, Email = "bala.edes@gmail.com", FelhasznaloId = 3, LetrehozasDatuma = new DateTime(2025, 02, 5), Nev = "Édes Bala", Telefon = "36202020222", Tema = "panasz", Uzenet = "Nem működik a rekesz."},
                new Kapcsolat {KapcsolatId = 4, Email = "gyuri.kovacs@gmail.com", FelhasznaloId = 4, LetrehozasDatuma = new DateTime(2025, 02, 4), Nev = "Kovács Gyuri", Telefon = "36301014725", Tema = "csomag", Uzenet = "Üres volt a csomagom."},
                new Kapcsolat {KapcsolatId = 5, Email = "piroska.ducsai@gmail.com", FelhasznaloId = 5, LetrehozasDatuma = new DateTime(2025, 02, 3), Nev = "Duncsai Piroskai", Telefon = "3630112233456", Tema = "csomag", Uzenet = "Nem azt kaptam amit rendeltem."}
           ];
        public Context CreateDbContext()
        {
            var connection = new SqliteConnection("DataSource=:memory:");
            connection.Open();
            var options = new DbContextOptionsBuilder<Context>()
                .UseSqlite(connection)
                .Options;

            _context = new Context(options);
            _context.Database.EnsureCreated();
            _context.Csomagok.AddRange(CsomagList);
            _context.Csomagautomatak.AddRange(CsomagautomataList);
            _context.Felhasznalok.AddRange(FelhasznaloList);
            _context.Futarok.AddRange(FutarList);
            _context.Jarmuk.AddRange(JarmuList);
            _context.Szallitasok.AddRange(SzallitasList);
            _context.Utvonalak.AddRange(UtvonalList);
            _context.Jelentkezesek.AddRange(JelentkezesList);
            _context.Kapcsolatok.AddRange(KapcsolatList);
            _context.SaveChanges();
            return _context;
        }

        internal void ClearAll()
        {
            foreach (var csomag in Context.Csomagok)
            {
                Context.Csomagok.Remove(csomag);
            }

            foreach (var csomagautomata in Context.Csomagautomatak)
            {
                Context.Csomagautomatak.Remove(csomagautomata);
            }

            foreach (var felhasznalo in Context.Felhasznalok)
            {
                Context.Felhasznalok.Remove(felhasznalo);
            }

            foreach (var futar in Context.Futarok)
            {
                Context.Futarok.Remove(futar);
            }

            foreach (var jarmu in Context.Jarmuk)
            {
                Context.Jarmuk.Remove(jarmu);
            }

            foreach (var szallitas in Context.Szallitasok)
            {
                Context.Szallitasok.Remove(szallitas);
            }

            foreach (var utvonal in Context.Utvonalak)
            {
                Context.Utvonalak.Remove(utvonal);
            }

            foreach(var jelentkezes in Context.Jelentkezesek)
            {
                Context.Jelentkezesek.Remove(jelentkezes);
            }

            foreach (var kapcsolat in Context.Kapcsolatok)
            {
                Context.Kapcsolatok.Remove(kapcsolat);
            }

            Context.SaveChanges();
        }
    }
}
