﻿using System.ComponentModel.DataAnnotations.Schema;

namespace FutarkezeloAPI.Model
{
    [Table("jelentkezesek")]
    public class Jelentkezes
    {
        [Column("jelentkezesId")]
        public int JelentkezesId { get; set; }

        [Column("felhasznalo_id")]
        public int? FelhasznaloId { get; set; }

        [Column("nev")]
        public string? Nev { get; set; }
        [Column("email")]
        public string? Email { get; set; }
        [Column("telefon")]
        public string? Telefon { get; set; }
        [Column("lakohely")]
        public string? Lakohely { get; set; }
        [Column("pozicio")]
        public string? Pozicio { get; set; }
        [Column("tapasztalat")]
        public string? Tapasztalat { get; set; }
        [Column("bemutatkozas")]
        public string? Bemutatkozas { get; set; }

        [Column("letrehozva")]
        public DateTime Letrehozva { get; set; } = DateTime.Now;

        
    }
}
