﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FutarkezeloAPI.Model
{
    [Table("szallitas")]
    public class Szallitas
    {
        [Column("csomag_id")]
        public int CsomagId { get; set; }

        [Column("jarmu_id")]
        public int JarmuId { get; set; }

        [Column("szallitas_id")]
        public int SzallitasId { get; set; }
        [Column("futar_id")] 
        public int FutarId { get; set; }
        [Column("utvonal_id")]
        public int UtvonalId { get; set; }
        [Column("idopont")]
        public DateTime Idopont { get; set; }
        [Column("allapot")]
        public string? Allapot { get; set; }

        [Column("varhato_erkezes")]
        public DateTime? VarhatoErkezes { get; set; }
    }
}
