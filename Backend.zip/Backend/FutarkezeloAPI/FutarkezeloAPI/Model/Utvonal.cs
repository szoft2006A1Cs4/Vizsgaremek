﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FutarkezeloAPI.Model
{
    [Table("utvonal")]
    public class Utvonal
    {
        [Column("utvonal_id")]
        public int UtvonalId { get; set; }
        [Column("kezdopont")]
        public string? KezdoPont { get; set; }
        [Column("vegpont")]
        public string? Vegpont { get; set; }
        [Column("hossz(km)")]
        public int Hossz { get; set; }
        [Column("forgalom")]
        public string? Forgalom { get; set; }
    }
}
