﻿using System.ComponentModel.DataAnnotations.Schema;

namespace FutarkezeloAPI.Model
{
    [Table("kapcsolat")]
    public class Kapcsolat
    {
        [Column("kapcsolat_id")]
        public int KapcsolatId { get; set; }

        [Column("felhasznalo_id")]
        public int? FelhasznaloId { get; set; }

        [Column("nev")]
        public string? Nev { get; set; }

        [Column("email")]
        public string? Email { get; set; }

        [Column("telefon")]
        public string? Telefon { get; set; }

        [Column("tema")]
        public string? Tema { get; set; }

        [Column("uzenet")]
        public string? Uzenet { get; set; }

        [Column("letrehozas_datuma")]
        public DateTime LetrehozasDatuma { get; set; } = DateTime.Now;
    }
}

