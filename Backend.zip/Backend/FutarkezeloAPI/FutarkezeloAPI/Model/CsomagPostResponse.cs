﻿namespace FutarkezeloAPI.Model
{
    public class CsomagPostResponse
    {
        public Csomag? csomag { get; set; }
        public Szallitas? szallitas { get; set; }
    }
}
