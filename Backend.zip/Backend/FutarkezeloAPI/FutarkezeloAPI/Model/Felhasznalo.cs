﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FutarkezeloAPI.Model
{
    [Table("felhasznalo")]
    public class Felhasznalo
    {
        [Column("felhasznalo_id")]
        public int FelhasznaloId { get; set; }
        [Column("nev")]
        public string? Nev { get; set; }
        [Column("email")]
        public string? Email { get; set; }
        [Column("telefonszam")]
        public string? Telefonszam { get; set; } 
        [Column("jelszo")]
        public string? Jelszo { get; set; } 
        [Column("jogosultsag")]
        public string? Jogosultsag { get; set; }
        [Column("token")]
        public string? Token { get; set; }
    }
}
