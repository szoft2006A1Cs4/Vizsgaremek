﻿using FutarkezeloAPI.Dto;
using Microsoft.EntityFrameworkCore;

namespace FutarkezeloAPI.Model
{
    public class Context : DbContext
    {
        public DbSet<Csomag> Csomagok { get; set; }
        public DbSet<Csomagautomata> Csomagautomatak {get; set; }
        public DbSet<Felhasznalo> Felhasznalok {get; set; }
        public DbSet<Futar> Futarok {get; set; }
        public DbSet<Jarmu> Jarmuk {get; set; }
        public DbSet<Szallitas> Szallitasok {get; set; }
        public DbSet<Utvonal> Utvonalak {get; set; }
        public DbSet<Jelentkezes> Jelentkezesek { get; set; }
        public DbSet<Kapcsolat> Kapcsolatok { get; set; }

        public Context(DbContextOptions<Context> options) : base(options)
        {
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Csomag>().ToTable("csomag");

            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Csomagautomata>().ToTable("csomagautomata");

            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Felhasznalo>().ToTable("felhasznalo");

            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Futar>().ToTable("futar");

            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Jarmu>().ToTable("jarmu");

            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Szallitas>().ToTable("szallitas");

            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Utvonal>().ToTable("utvonal");

            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Jelentkezes>().ToTable("jelentkezesek");

            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Kapcsolat>().ToTable("kapcsolat");


            // Ez azért kell hogy a ProfilUpdateRequest osztályt ne vegye adatbázis táblának. Nem arra van kitalálva.
            modelBuilder.Ignore<ProfilUpdateRequest>();

        }



}
}
