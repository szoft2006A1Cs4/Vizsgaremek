﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FutarkezeloAPI.Model
{
    [Table("jarmu")]
    public class Jarmu
    {
        [Column("jarmu_id")]
        public int JarmuId { get; set; }
        [Column("rendszam")]
        public string? Rendszam { get; set; }
        [Column("tipus")]
        public string? Tipus { get; set; }
        [Column("kapacitas_kg")]
        public int Kapacitas_Kg { get; set; }
        [Column("allapot")]
        public string? Allapot { get; set; }
    }
}
