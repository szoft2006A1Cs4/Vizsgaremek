﻿namespace FutarkezeloAPI.Model
{
    public class LoginRequest
    {
        public string? Email { get; set; }
        public string? Jelszo { get; set; }
    }
}
