﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FutarkezeloAPI.Model
{
    [Table("futar")]
    public class Futar
    {
        [Column("futar_id")]
        public int FutarId { get; set; }
        [Column("nev")]
        public string? Nev { get; set; }
        [Column("elerhetoseg")]
        public string? Elerhetoseg { get; set; }
        [Column("jogositvany_tipus")]
        public string? Jogositvany_Tipus { get; set; }
        [Column("munka_kezdese")]
        public DateTime Munka_Kezdese { get; set; }
        [Column("jarmu_id")]
        public int JarmuId { get; set; }
    }
}
