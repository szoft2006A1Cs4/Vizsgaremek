﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FutarkezeloAPI.Model
{
    [Table("csomagautomata")]
    public class Csomagautomata
    {
        [Column("csomagautomata_id")]
        public int CsomagautomataId { get; set; }
        [Column("helyszin")]
        public string? Helyszin { get; set; }
        [Column("iranyitoszam")]
        public int Iranyitoszam { get; set; }
        [Column("lat")]
        public decimal? Lat { get; set; }
        [Column("lng")]
        public decimal? Lng { get; set; }
        [Column("nyitvatartas")]
        public string? Nyitvatartas { get; set; }
        [Column("utvonal_id")]
        public int UtvonalId { get; set; }
    }
}
