﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FutarkezeloAPI.Model
{
    [Table("csomag")]
    public class Csomag
    {
        [Column("csomag_id")]
        public int CsomagId { get; set; }

        [Column("leiras")]
        public string? Leiras { get; set; }

        [Column("meret")]
        public string? Meret { get; set; }

        [Column("suly")]
        public double Suly { get; set; }

        [Column("csomagautomata_id")]
        public int CsomagautomataId { get; set; }

        [Column("felhasznalo_id")]
        public int FelhasznaloId { get; set; }

        [Column("felado_nev")]
        public string? FeladoNev { get; set; }

        [Column("felado_telefonszam")]
        public string? FeladoTelefonszam { get; set; }

        [Column("felado_email")]
        public string? FeladoEmail { get; set; }

        [Column("cimzett_nev")]
        public string? CimzettNev { get; set; }

        [Column("cimzett_telefonszam")]
        public string? CimzettTelefonszam { get; set; }

        [Column("torekeny")]
        public bool Torekeny { get; set; }

        [Column("szallitasi_dij")]
        public decimal? SzallitasiDij { get; set; }

        [Column("cimzett_email")]
        public string? CimzettEmail { get; set; }

    }
}
