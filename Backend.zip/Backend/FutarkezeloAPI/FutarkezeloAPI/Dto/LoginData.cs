﻿namespace FutarkezeloAPI.Dto
{
    public class LoginData
    {
        public required string Email { get; set; }
        public required string Password { get; set; }
    }
}
