﻿namespace FutarkezeloAPI.Dto
{
    public class ProfilUpdateRequest
    {
        public string Nev { get; set; } = "";
        public string Email { get; set; } = "";
        public string Telefonszam { get; set; } = "";

        public string? RegiJelszo { get; set; }
        public string? UjJelszo { get; set; }
    }
}
