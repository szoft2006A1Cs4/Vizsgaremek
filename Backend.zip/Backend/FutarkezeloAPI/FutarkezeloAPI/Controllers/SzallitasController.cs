﻿using FutarkezeloAPI.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace FutarkezeloAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SzallitasController : Controller
    {
        private Context _context;

        public SzallitasController(Context context)
        {
            _context = context;
        }

        [Authorize(Policy = "Szallitas.Read")]
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var list = await _context.Szallitasok.ToListAsync();
            return Ok(list);
        }
        [Authorize(Policy = "Szallitas.Read")]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var szallitas = await _context.Szallitasok.FirstOrDefaultAsync(p => p.SzallitasId == id);
            if (szallitas != null) return Ok(szallitas);
            else return NotFound();
        }

        [Authorize(Policy = "Szallitas.Read")]
        [HttpGet("sajat-csomagok")]
        public async Task<IActionResult> SajatCsomagok()
        {
            var userEmail = User.FindFirst(ClaimTypes.Name)?.Value;

            if (string.IsNullOrWhiteSpace(userEmail))
            {
                return Unauthorized("Nem azonosítható a felhasználó.");
            }

            var felhasznalo = await _context.Felhasznalok
                .FirstOrDefaultAsync(f => f.Email == userEmail);

            if (felhasznalo == null)
            {
                return NotFound("A felhasználó nem található.");
            }

            var csomagok = await _context.Csomagok
                .Where(c => c.CimzettNev == felhasznalo.Nev)
                .Select(c => new
                {
                    csomagId = c.CsomagId,
                    leiras = c.Leiras
                })
                .ToListAsync();

            return Ok(csomagok);
        }

        [Authorize(Policy = "Szallitas.Create")]
        [HttpPost]
        public async Task<IActionResult> Post(Szallitas szallitas)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (szallitas.Allapot == "Folyamatban" && !szallitas.VarhatoErkezes.HasValue)
            {
                szallitas.VarhatoErkezes = szallitas.Idopont.AddHours(3);
            }

            _context.Szallitasok.Add(szallitas);
            await _context.SaveChangesAsync();
            return Created(Request.GetDisplayUrl() + szallitas.SzallitasId, szallitas);
        }

        [Authorize(Policy = "Szallitas.Update")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, Szallitas szallitas)
        {
            if (string.IsNullOrWhiteSpace(szallitas.Allapot) || szallitas.Idopont == DateTime.MinValue)
            {
                return BadRequest("Hibás vagy hiányzó adatok!");
            }
            var list = await _context.Szallitasok.ToListAsync();
            var oldSzallitas = list.FirstOrDefault(p => p.SzallitasId == id);
            if (oldSzallitas == null) return NotFound();
            foreach (var propInfo in typeof(Szallitas).GetProperties())
            {
                propInfo.SetValue(oldSzallitas, propInfo.GetValue(szallitas));
            }
            await _context.SaveChangesAsync();
            return Ok(oldSzallitas);
        }

        [Authorize(Policy = "Szallitas.Update")]
        [HttpPut("visszakuldes/{csomagId}")]
        public async Task<IActionResult> Visszakuldes(int csomagId)
        {
            var userEmail = User.FindFirst(ClaimTypes.Name)?.Value;

            if (string.IsNullOrWhiteSpace(userEmail))
            {
                return Unauthorized("Nem azonosítható a felhasználó.");
            }

            var felhasznalo = await _context.Felhasznalok
                .FirstOrDefaultAsync(f => f.Email == userEmail);

            if (felhasznalo == null)
            {
                return NotFound("A felhasználó nem található.");
            }

            var csomag = await _context.Csomagok
                .FirstOrDefaultAsync(c => c.CsomagId == csomagId);

            if (csomag == null)
            {
                return NotFound("A csomag nem létezik.");
            }

            if (csomag.CimzettNev != felhasznalo.Nev)
            {
                return BadRequest("Ez a csomag nem neked lett címezve.");
            }

            var szallitas = await _context.Szallitasok
                .FirstOrDefaultAsync(s => s.CsomagId == csomagId);

            if (szallitas == null)
            {
                return NotFound("Ehhez a csomaghoz nem található szállítás.");
            }

            if (szallitas.Allapot == "Teljesítve")
            {
                return BadRequest("A teljesített csomagot nem lehet visszaküldeni.");
            }

            szallitas.Allapot = "Törölve";
            await _context.SaveChangesAsync();

            return Ok(new
            {
                message = "A csomag státusza sikeresen Törölve lett."
            });
        }


        [Authorize(Policy = "Szallitas.Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var list = await _context.Szallitasok.ToListAsync();
            var szallitas = list.FirstOrDefault(p => p.SzallitasId == id);
            if (szallitas == null) return NotFound();
            _context.Szallitasok.Remove(szallitas);
            await _context.SaveChangesAsync();
            return Ok(szallitas);
        }
    }
}
