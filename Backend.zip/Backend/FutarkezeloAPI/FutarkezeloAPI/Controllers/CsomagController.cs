﻿using FutarkezeloAPI.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace FutarkezeloAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CsomagController : ControllerBase
    {
        private Context _context;

        public CsomagController(Context context)
        {
            _context = context;
        }

        [Authorize(Policy = "Csomag.Read")]
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var list = await _context.Csomagok.ToListAsync();
            return Ok(list);
        }
        [Authorize(Policy = "Csomag.Read")]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id) 
        {
            var csomag = await _context.Csomagok.FirstOrDefaultAsync(p => p.CsomagId == id);
            if (csomag != null) return Ok(csomag);
            else return NotFound();
        }

        [Authorize(Policy = "Csomag.Read")]
        [HttpGet("kovetes/{id}")]
        public async Task<IActionResult> Kovetes(int id)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdClaim, out int userId))
            {
                return Unauthorized("Nem azonosítható a bejelentkezett felhasználó.");
            }

            var bejelentkezettUser = await _context.Felhasznalok
                .FirstOrDefaultAsync(u => u.FelhasznaloId == userId);

            if (bejelentkezettUser == null)
            {
                return Unauthorized("Felhasználó nem található.");
            }

            var userEmail = bejelentkezettUser.Email;

            var csomag = await _context.Csomagok
                .FirstOrDefaultAsync(c =>
                    c.CsomagId == id &&
                    (
                        c.FelhasznaloId == userId ||
                        c.CimzettEmail == userEmail
                    )
                );

            if (csomag == null)
            {
                return NotFound("Ehhez a csomagazonosítóhoz nem tartozik saját csomag.");
            }

            var szallitas = await _context.Szallitasok
                .FirstOrDefaultAsync(s => s.CsomagId == id);

            if (szallitas == null)
            {
                return NotFound("Ehhez a csomaghoz nem található szállítás.");
            }

            var jarmu = await _context.Jarmuk
                .FirstOrDefaultAsync(j => j.JarmuId == szallitas.JarmuId);

            var automata = await _context.Csomagautomatak
                .FirstOrDefaultAsync(a => a.UtvonalId == szallitas.UtvonalId);

            if (szallitas.Allapot == "Folyamatban" &&
                szallitas.VarhatoErkezes.HasValue &&
                szallitas.VarhatoErkezes.Value <= DateTime.Now)
            {
                szallitas.Allapot = "Teljesítve";

                if (jarmu != null)
                {
                    jarmu.Allapot = "Szabad";
                }

                await _context.SaveChangesAsync();
            }

            var statusz = "Ismeretlen";

            if (szallitas.Allapot == "Folyamatban")
                statusz = "Úton";
            else if (szallitas.Allapot == "Teljesítve")
                statusz = "Teljesítve";
            else if (szallitas.Allapot == "Törölve")
                statusz = "Törölve";

            return Ok(new
            {
                statusz = statusz,
                leiras = csomag.Leiras,
                hely = automata != null ? automata.Helyszin : "-",
                allapot = szallitas.Allapot,
                szallitasModja = "Járműves szállítás",
                jarmuTipusa = jarmu != null ? jarmu.Tipus : "-",
                rendszam = jarmu != null ? jarmu.Rendszam : "-",
                jarmuAllapota = jarmu != null ? jarmu.Allapot : "-",
                varhatoErkezes = szallitas.Allapot == "Teljesítve"
                    ? "Célbaért"
                    : szallitas.VarhatoErkezes?.ToString("yyyy-MM-ddTHH:mm:ss"),
                meret = csomag.Meret,
                suly = csomag.Suly
            });
        }

        [Authorize(Policy = "Csomag.Create")]
        [HttpPost]
        public async Task<IActionResult> Post(Csomag csomag)
        {
            if (string.IsNullOrWhiteSpace(csomag.Meret) ||
                csomag.Suly <= 0 ||
                csomag.CsomagautomataId <= 0 ||
                csomag.FelhasznaloId <= 0)
            {
                return BadRequest("Hibás vagy hiányzó adatok!");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            decimal dij = 0;

            if (csomag.Meret == "S") dij = 1490;
            else if (csomag.Meret == "M") dij = 1990;
            else if (csomag.Meret == "L") dij = 2490;
            else return BadRequest("Érvénytelen méret!");

            if (csomag.Suly > 5) dij += 700;
            else if (csomag.Suly > 2) dij += 300;

            if (csomag.Torekeny) dij += 500;

            csomag.SzallitasiDij = dij;

            var automata = await _context.Csomagautomatak
                .FirstOrDefaultAsync(a => a.CsomagautomataId == csomag.CsomagautomataId);

            if (automata == null)
            {
                return BadRequest("Csomagautomata nem található.");
            }

            var utvonal = await _context.Utvonalak
                .FirstOrDefaultAsync(u => u.UtvonalId == automata.UtvonalId);

            if (utvonal == null)
            {
                return BadRequest("Útvonal nem található.");
            }

            utvonal.Vegpont = automata.Helyszin;

            var futarIds = await _context.Futarok
                .Select(f => f.FutarId)
                .ToListAsync();

            if (futarIds.Count == 0)
            {
                return BadRequest("Nincs elérhető futár.");
            }

            var jarmuIds = await _context.Jarmuk
                .Where(j => j.Allapot == "Használatban")
                .Select(j => j.JarmuId)
                .ToListAsync();

            if (jarmuIds.Count == 0)
            {
                return BadRequest("Nincs elérhető jármű.");
            }

            _context.Csomagok.Add(csomag);
            await _context.SaveChangesAsync();

            var random = new Random();

            var randomFutarId = futarIds[random.Next(futarIds.Count)];
            var randomJarmuId = jarmuIds[random.Next(jarmuIds.Count)];

            var indulasiIdo = DateTime.Now;
            var varhatoErkezes = indulasiIdo.AddHours(random.Next(3, 25));

            var szallitas = new Szallitas
            {
                CsomagId = csomag.CsomagId,
                FutarId = randomFutarId,
                UtvonalId = utvonal.UtvonalId,
                JarmuId = randomJarmuId,
                Idopont = indulasiIdo,
                Allapot = "Folyamatban",
                VarhatoErkezes = varhatoErkezes
            };

            _context.Szallitasok.Add(szallitas);
            await _context.SaveChangesAsync();

            return Created(Request.GetDisplayUrl() + csomag.CsomagId, new CsomagPostResponse
            {
                csomag = csomag,
                szallitas = szallitas
            });
        }

        [Authorize(Policy = "Csomag.Update")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, Csomag csomag)
        {
            if (string.IsNullOrWhiteSpace(csomag.Leiras) || string.IsNullOrWhiteSpace(csomag.Meret)
                || csomag.Suly == 0)
            {
                return BadRequest("Hibás vagy hiányzó adatok!");
            }
            var list = await _context.Csomagok.ToListAsync();
            var oldCsomag = list.FirstOrDefault(p => p.CsomagId == id);
            if (oldCsomag == null) return NotFound();
            foreach (var propInfo in typeof(Csomag).GetProperties())
            {
                propInfo.SetValue(oldCsomag, propInfo.GetValue(csomag));
            }
            await _context.SaveChangesAsync();
            return Ok(oldCsomag);
        }

        [Authorize(Policy = "Csomag.Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var list = await _context.Csomagok.ToListAsync();
            var csomag = list.FirstOrDefault(p => p.CsomagId == id);
            if (csomag == null) return NotFound();
            _context.Csomagok.Remove(csomag);
            await _context.SaveChangesAsync();
            return Ok(csomag);
        }
    }
}

