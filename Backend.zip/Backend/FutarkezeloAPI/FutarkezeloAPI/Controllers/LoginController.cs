﻿using FutarkezeloAPI.Auth;
using FutarkezeloAPI.Dto;
using FutarkezeloAPI.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace FutarkezeloAPI.Controllers
{
    [Route("api/login")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private Context _context;
        private readonly TokenManager _tokenManager;

        public LoginController(Context context, TokenManager tokenManager)
        {
            _context = context;
            _tokenManager = tokenManager;
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Login([FromBody] FutarkezeloAPI.Model.LoginRequest request)
        {
            var user = await _context.Felhasznalok
                .FirstOrDefaultAsync(x => x.Email == request.Email);

            if (user == null)
            {
                return Unauthorized("Nincs ilyen email az adatbázisban.");
            }

            if (!PasswordHandler.VerifyPassword(request.Jelszo, user.Jelszo))
            {
                return Unauthorized("A jelszó nem egyezik.");
            }

            var token = _tokenManager.GenerateToken(user);

            user.Token = token;
            await _context.SaveChangesAsync();

            return Ok(new
            {
                token = token,
                userId = user.FelhasznaloId,
                nev = user.Nev,
                email = user.Email,
                telefonszam = user.Telefonszam
            });
        }

        [Authorize]
        [HttpDelete]
        public async Task<IActionResult> Logout()
        {
            var email = User.FindFirst(ClaimTypes.Name)?.Value;
            if (string.IsNullOrEmpty(email)) return Unauthorized();
            var felhasznalo = await _context.Felhasznalok.FirstOrDefaultAsync(u => u.Email == email);
            if (felhasznalo == null) return Unauthorized();
            felhasznalo.Token = null;
            await _context.SaveChangesAsync();
            return Ok();
        }
    }
}
