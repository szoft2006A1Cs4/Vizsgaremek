﻿using FutarkezeloAPI.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FutarkezeloAPI.Controllers
{
    [AllowAnonymous]
    [ApiController]
    [Route("api/[controller]")]
    public class KapcsolatController : ControllerBase
    {
        private readonly Context _context;

        public KapcsolatController(Context context)
        {
            _context = context;
        }

        [Authorize(Policy = "Kapcsolat.Read")]
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var list = await _context.Kapcsolatok.ToListAsync();
            return Ok(list);
        }

        [Authorize(Policy = "Kapcsolat.Read")]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var kapcsolat = await _context.Kapcsolatok.FirstOrDefaultAsync(p => p.KapcsolatId == id);
            if (kapcsolat != null) return Ok(kapcsolat);
            else return NotFound();
        }
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Post(Kapcsolat kapcsolat)
        {
            if (string.IsNullOrWhiteSpace(kapcsolat.Nev) ||
                string.IsNullOrWhiteSpace(kapcsolat.Email) ||
                string.IsNullOrWhiteSpace(kapcsolat.Telefon) ||
                string.IsNullOrWhiteSpace(kapcsolat.Uzenet))
            {
                return BadRequest("Hiányzó kötelező adatok.");
            }

            if (User.Identity != null && User.Identity.IsAuthenticated)
            {
                var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

                if (int.TryParse(userIdClaim, out int userId))
                {
                    kapcsolat.FelhasznaloId = userId;
                }
                else
                {
                    kapcsolat.FelhasznaloId = null;
                }
            }
            else
            {
                kapcsolat.FelhasznaloId = null;
            }

            if (string.IsNullOrWhiteSpace(kapcsolat.Tema))
            {
                kapcsolat.Tema = "Kapcsolat";
            }

            kapcsolat.LetrehozasDatuma = DateTime.Now;

            try
            {
                _context.Kapcsolatok.Add(kapcsolat);
                await _context.SaveChangesAsync();

                return Created(Request.GetDisplayUrl() + kapcsolat.KapcsolatId, kapcsolat);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException?.Message ?? ex.Message);
            }
        }

        [Authorize(Policy = "Kapcsolat.Update")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, Kapcsolat kapcsolat)
        {
            var list = await _context.Kapcsolatok.ToListAsync();
            var oldKapcsolat = list.FirstOrDefault(p => p.KapcsolatId == id);
            if (oldKapcsolat == null) return NotFound();
            foreach (var propInfo in typeof(Kapcsolat).GetProperties())
            {
                propInfo.SetValue(oldKapcsolat, propInfo.GetValue(kapcsolat));
            }
            await _context.SaveChangesAsync();
            return Ok(oldKapcsolat);
        }

        [Authorize(Policy = "Kapcsolat.Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var list = await _context.Kapcsolatok.ToListAsync();
            var kapcsolat = list.FirstOrDefault(p => p.KapcsolatId == id);
            if (kapcsolat == null) return NotFound();
            _context.Kapcsolatok.Remove(kapcsolat);
            await _context.SaveChangesAsync();
            return Ok(kapcsolat);
        }
    }
}
