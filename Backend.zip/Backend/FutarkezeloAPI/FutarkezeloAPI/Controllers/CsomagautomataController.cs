﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FutarkezeloAPI.Model;
using Microsoft.AspNetCore.Authorization;

namespace FutarkezeloAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CsomagautomataController : ControllerBase
    {
        private Context _context;

        public CsomagautomataController(Context context)
        {
            _context = context;
        }

        [AllowAnonymous]
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var list = await _context.Csomagautomatak.ToListAsync();
            return Ok(list);
        }

        [AllowAnonymous]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var automata = await _context.Csomagautomatak
                .FirstOrDefaultAsync(x => x.CsomagautomataId == id);

            if (automata == null)
                return NotFound();

            return Ok(automata);
        }

        [Authorize(Policy = "Csomagautomata.Create")]
        [HttpPost]
        public async Task<IActionResult> Post(Csomagautomata csomagautomata)
        {
            if (string.IsNullOrWhiteSpace(csomagautomata.Helyszin) || string.IsNullOrWhiteSpace(csomagautomata.Nyitvatartas)
                || csomagautomata.Lat == null || csomagautomata.Lng == null || csomagautomata.Iranyitoszam == 0)
            {
                return BadRequest("Hibás vagy hiányzó adatok!");
            }
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            _context.Csomagautomatak.Add(csomagautomata);
            await _context.SaveChangesAsync();
            return Created(Request.GetDisplayUrl() + csomagautomata.CsomagautomataId, csomagautomata);
        }

        [Authorize(Policy = "Csomagautomata.Update")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, Csomagautomata csomagautomata)
        {
            if (string.IsNullOrWhiteSpace(csomagautomata.Helyszin) || string.IsNullOrWhiteSpace(csomagautomata.Nyitvatartas)
                || csomagautomata.Lat == null || csomagautomata.Lng == null || csomagautomata.Iranyitoszam == 0)
            {
                return BadRequest("Hibás vagy hiányzó adatok!");
            }
            var list = await _context.Csomagautomatak.ToListAsync();
            var oldCsomagautomata = list.FirstOrDefault(p => p.CsomagautomataId == id);
            if (oldCsomagautomata == null) return NotFound();
            foreach (var propInfo in typeof(Csomagautomata).GetProperties())
            {
                propInfo.SetValue(oldCsomagautomata, propInfo.GetValue(csomagautomata));
            }
            await _context.SaveChangesAsync();
            return Ok(oldCsomagautomata);
        }

        [Authorize(Policy = "Csomagautomata.Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var list = await _context.Csomagautomatak.ToListAsync();
            var csomagautomata = list.FirstOrDefault(p => p.CsomagautomataId == id);
            if (csomagautomata == null) return NotFound();
            _context.Csomagautomatak.Remove(csomagautomata);
            await _context.SaveChangesAsync();
            return Ok(csomagautomata);
        }
    }
}
