﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FutarkezeloAPI.Model;
using Microsoft.AspNetCore.Authorization;

namespace FutarkezeloAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FutarController : Controller
    {
        private Context _context;

        public FutarController(Context context)
        {
            _context = context;
        }

        [AllowAnonymous]
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var list = await _context.Futarok.ToListAsync();
            return Ok(list);
        }

        [AllowAnonymous]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var futar = await _context.Futarok.FirstOrDefaultAsync(p => p.FutarId == id);
            if (futar != null) return Ok(futar);
            else return NotFound();
        }

        [Authorize(Policy = "Futar.Create")]
        [HttpPost]
        public async Task<IActionResult> Post(Futar futar)
        {
            if (!ModelState.IsValid ||
                string.IsNullOrWhiteSpace(futar.Nev) ||
                string.IsNullOrWhiteSpace(futar.Elerhetoseg) ||
                string.IsNullOrWhiteSpace(futar.Jogositvany_Tipus) ||
                futar.Munka_Kezdese == default)
            {
                return BadRequest(ModelState);
            }

            _context.Futarok.Add(futar);
            await _context.SaveChangesAsync();
            return Created(Request.GetDisplayUrl() + "/" + futar.FutarId, futar);
        }

        [Authorize(Policy = "Futar.Update")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, Futar futar)
        {
            if (!ModelState.IsValid ||
                string.IsNullOrWhiteSpace(futar.Nev) ||
                string.IsNullOrWhiteSpace(futar.Elerhetoseg) ||
                string.IsNullOrWhiteSpace(futar.Jogositvany_Tipus) ||
                futar.Munka_Kezdese == default)
            {
                return BadRequest(ModelState);
            }

            var oldFutar = await _context.Futarok.FirstOrDefaultAsync(p => p.FutarId == id);
            if (oldFutar == null) return NotFound();

            oldFutar.Nev = futar.Nev;
            oldFutar.Elerhetoseg = futar.Elerhetoseg;
            oldFutar.Jogositvany_Tipus = futar.Jogositvany_Tipus;
            oldFutar.Munka_Kezdese = futar.Munka_Kezdese;
            oldFutar.JarmuId = futar.JarmuId;

            await _context.SaveChangesAsync();
            return Ok(oldFutar);
        }

        [Authorize(Policy = "Futar.Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var list = await _context.Futarok.ToListAsync();
            var futar = list.FirstOrDefault(p => p.FutarId == id);
            if (futar == null) return NotFound();
            _context.Futarok.Remove(futar);
            await _context.SaveChangesAsync();
            return Ok(futar);
        }
    }
}
