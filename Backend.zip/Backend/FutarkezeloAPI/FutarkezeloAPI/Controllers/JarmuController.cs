﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using FutarkezeloAPI.Model;

namespace JarmukezeloAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JarmuController : Controller
    {

        private Context _context;

        public JarmuController(Context context)
        {
            _context = context;
        }

        [Authorize(Policy = "Jarmu.Read")]
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var list = await _context.Jarmuk.ToListAsync();
            return Ok(list);
        }

        [Authorize(Policy = "Jarmu.Read")]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var jarmu = await _context.Jarmuk.FirstOrDefaultAsync(p => p.JarmuId == id);
            if (jarmu != null) return Ok(jarmu);
            else return NotFound();
        }

        [Authorize(Policy = "Jarmu.Create")]
        [HttpPost]
        public async Task<IActionResult> Post(Jarmu jarmu)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            _context.Jarmuk.Add(jarmu);
            await _context.SaveChangesAsync();
            return Created(Request.GetDisplayUrl() + jarmu.JarmuId, jarmu);
        }

        [Authorize(Policy = "Jarmu.Update")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, Jarmu jarmu)
        {
            var list = await _context.Jarmuk.ToListAsync();
            var oldJarmu = list.FirstOrDefault(p => p.JarmuId == id);
            if (oldJarmu == null) return NotFound();
            foreach (var propInfo in typeof(Jarmu).GetProperties())
            {
                propInfo.SetValue(oldJarmu, propInfo.GetValue(jarmu));
            }
            await _context.SaveChangesAsync();
            return Ok(oldJarmu);
        }

        [Authorize(Policy = "Jarmu.Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var list = await _context.Jarmuk.ToListAsync();
            var jarmu = list.FirstOrDefault(p => p.JarmuId == id);
            if (jarmu == null) return NotFound();
            _context.Jarmuk.Remove(jarmu);
            await _context.SaveChangesAsync();
            return Ok(jarmu);
        }
    }
    
}
