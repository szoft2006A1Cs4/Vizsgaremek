﻿
using FutarkezeloAPI.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Text.RegularExpressions;

namespace FutarkezeloAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JelentkezesController : ControllerBase
    {
        private readonly Context _context;

        public JelentkezesController(Context context)
        {
            _context = context;
        }
        [Authorize(Policy = "Jelentkezes.Read")]
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var list = await _context.Jelentkezesek.ToListAsync();

            return Ok(list);
        }

        [Authorize(Policy = "Jelentkezes.Read")]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var jelentkezes = await _context.Jelentkezesek.FirstOrDefaultAsync(p => p.JelentkezesId == id);
            if (jelentkezes != null) return Ok(jelentkezes);
            else return NotFound();
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Jelentkezes jelentkezes)
        {
            if (string.IsNullOrWhiteSpace(jelentkezes.Nev) ||
                string.IsNullOrWhiteSpace(jelentkezes.Email) ||
                string.IsNullOrWhiteSpace(jelentkezes.Telefon) ||
                string.IsNullOrWhiteSpace(jelentkezes.Lakohely) ||
                string.IsNullOrWhiteSpace(jelentkezes.Pozicio) ||
                string.IsNullOrWhiteSpace(jelentkezes.Tapasztalat) ||
                string.IsNullOrWhiteSpace(jelentkezes.Bemutatkozas))
            {
                return BadRequest("Hiányzó kötelező adatok.");
            }

            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            
            if (!int.TryParse(userIdClaim, out int userId))
            {
                return Unauthorized("Nem azonosítható a bejelentkezett felhasználó.");
            }

            jelentkezes.FelhasznaloId = userId;
            jelentkezes.Letrehozva = DateTime.Now;

            try
            {
                _context.Jelentkezesek.Add(jelentkezes);
                await _context.SaveChangesAsync();

                return Created(Request.GetDisplayUrl() + jelentkezes.JelentkezesId, jelentkezes);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException?.Message ?? ex.Message);
            }

        }

        [Authorize(Policy = "Jelentkezes.Update")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, Jelentkezes jelentkezes)
        {
            var list = await _context.Jelentkezesek.ToListAsync();
            var oldJelentkezes = list.FirstOrDefault(p => p.JelentkezesId == id);
            if (oldJelentkezes == null) return NotFound();
            if (string.IsNullOrEmpty(jelentkezes.Nev) || string.IsNullOrWhiteSpace(jelentkezes.Telefon) 
                || string.IsNullOrWhiteSpace(jelentkezes.Pozicio) || string.IsNullOrWhiteSpace(jelentkezes.Tapasztalat)
                || string.IsNullOrWhiteSpace(jelentkezes.Lakohely)
                ) return BadRequest();

            foreach (var propInfo in typeof(Jelentkezes).GetProperties())
            {
                propInfo.SetValue(oldJelentkezes, propInfo.GetValue(jelentkezes));
            }
            await _context.SaveChangesAsync();
            return Ok(oldJelentkezes);
        }

        [Authorize(Policy = "Jelentkezes.Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var jelentkezes = await _context.Jelentkezesek.FirstOrDefaultAsync(p => p.JelentkezesId == id);
            if (jelentkezes == null) return NotFound();
            _context.Jelentkezesek.Remove(jelentkezes);
            await _context.SaveChangesAsync();
            return Ok(jelentkezes);
        }

    }
}