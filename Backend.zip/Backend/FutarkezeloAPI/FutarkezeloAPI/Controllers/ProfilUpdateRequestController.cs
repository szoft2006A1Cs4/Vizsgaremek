﻿using FutarkezeloAPI.Auth;
using FutarkezeloAPI.Dto;
using FutarkezeloAPI.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace FutarkezeloAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProfilUpdateRequestController : ControllerBase
    {

        private readonly Context _context;

        public ProfilUpdateRequestController(Context context)
        {
            _context = context;
        }

        [Authorize]
        [HttpPut("profil")]
        public async Task<IActionResult> ProfilModositas(ProfilUpdateRequest request)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdClaim, out int userId))
                return Unauthorized("Nem azonosítható felhasználó.");

            var user = await _context.Felhasznalok
                .FirstOrDefaultAsync(x => x.FelhasznaloId == userId);

            if (user == null)
                return NotFound("Felhasználó nem található.");

            if (string.IsNullOrWhiteSpace(request.Nev) ||
                string.IsNullOrWhiteSpace(request.Email) ||
                string.IsNullOrWhiteSpace(request.Telefonszam))
            {
                return BadRequest("Hiányzó adatok.");
            }

            var regiEmail = user.Email;
            var regiNev = user.Nev;

            var ujNev = request.Nev.Trim();
            var ujEmail = request.Email.Trim();
            var ujTelefonszam = request.Telefonszam.Trim();

            user.Nev = ujNev;
            user.Email = ujEmail;
            user.Telefonszam = ujTelefonszam;

            if (!string.IsNullOrWhiteSpace(regiEmail))
            {
                var cimzettCsomagok = await _context.Csomagok
                    .Where(c => c.CimzettEmail == regiEmail)
                    .ToListAsync();

                foreach (var csomag in cimzettCsomagok)
                {
                    csomag.CimzettEmail = ujEmail;
                    csomag.CimzettNev = ujNev;
                    csomag.CimzettTelefonszam = ujTelefonszam;
                }
            }

            var feladoCsomagok = await _context.Csomagok
                .Where(c => c.FelhasznaloId == user.FelhasznaloId)
                .ToListAsync();

            foreach (var csomag in feladoCsomagok)
            {
                csomag.FeladoNev = ujNev;
                csomag.FeladoEmail = ujEmail;
                csomag.FeladoTelefonszam = ujTelefonszam;
            }

            if (!string.IsNullOrWhiteSpace(request.UjJelszo))
            {
                if (string.IsNullOrWhiteSpace(request.RegiJelszo))
                    return BadRequest("A régi jelszó megadása kötelező.");

                if (string.IsNullOrWhiteSpace(user.Jelszo))
                    return BadRequest("A felhasználóhoz nincs mentett jelszó.");

                var regiJelszoJo = PasswordHandler.VerifyPassword(
                    request.RegiJelszo,
                    user.Jelszo
                );

                if (!regiJelszoJo)
                    return BadRequest("A régi jelszó hibás.");

                user.Jelszo = PasswordHandler.HashPassword(request.UjJelszo);
            }

            await _context.SaveChangesAsync();

            return Ok(new
            {
                user.FelhasznaloId,
                user.Nev,
                user.Email,
                user.Telefonszam,
                user.Jogosultsag
            });
        }
    }
}

