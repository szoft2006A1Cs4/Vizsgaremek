﻿using FutarkezeloAPI.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FutarkezeloAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UtvonalController : ControllerBase
    {
        private Context _context;

        public UtvonalController(Context context)
        {
            _context = context;
        }

        [Authorize(Policy = "Utvonal.Read")]
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var list = await _context.Utvonalak.ToListAsync();
            return Ok(list);
        }

        [Authorize(Policy = "Utvonal.Read")]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var utvonal = await _context.Utvonalak.FirstOrDefaultAsync(p => p.UtvonalId == id);
            if (utvonal != null) return Ok(utvonal);
            else return NotFound();
        }

        [Authorize(Policy = "Utvonal.Create")]
        [HttpPost]
        public async Task<IActionResult> Post(Utvonal utvonal)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            _context.Utvonalak.Add(utvonal);
            await _context.SaveChangesAsync();
            return Created(Request.GetDisplayUrl() + utvonal.UtvonalId, utvonal);
        }

        [Authorize(Policy = "Utvonal.Update")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, Utvonal utvonal)
        {
            var list = await _context.Utvonalak.ToListAsync();
            var oldUtvonal = list.FirstOrDefault(p => p.UtvonalId == id);
            if (oldUtvonal == null) return NotFound();
            foreach (var propInfo in typeof(Utvonal).GetProperties())
            {
                propInfo.SetValue(oldUtvonal, propInfo.GetValue(utvonal));
            }
            await _context.SaveChangesAsync();
            return Ok(oldUtvonal);
        }

        [Authorize(Policy = "Utvonal.Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var list = await _context.Utvonalak.ToListAsync();
            var utvonal = list.FirstOrDefault(p => p.UtvonalId == id);
            if (utvonal == null) return NotFound();
            _context.Utvonalak.Remove(utvonal);
            await _context.SaveChangesAsync();
            return Ok(utvonal);
        }
    }
}
