﻿using FutarkezeloAPI.Auth;
using FutarkezeloAPI.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;

namespace FutarkezeloAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FelhasznaloController : ControllerBase
    {
        private Context _context;

        public FelhasznaloController(Context context)
        {
            _context = context;
        }

        [Authorize(Policy = "Felhasznalo.Read")]
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var list = await _context.Felhasznalok.ToListAsync();
            return Ok(list);
        }

        [Authorize(Policy = "Felhasznalo.Read")]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var felhasznalo = await _context.Felhasznalok.FirstOrDefaultAsync(p => p.FelhasznaloId == id);
            if (felhasznalo != null) return Ok(felhasznalo);
            else return NotFound();
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Post(Felhasznalo felhasznalo)
        {
            if (string.IsNullOrWhiteSpace(felhasznalo.Email) || string.IsNullOrWhiteSpace(felhasznalo.Nev)
                || string.IsNullOrWhiteSpace(felhasznalo.Jelszo) || string.IsNullOrWhiteSpace(felhasznalo.Telefonszam))
            {
                return BadRequest("Hibás vagy hiányzó adatok!");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (string.IsNullOrWhiteSpace(felhasznalo.Jogosultsag))
                felhasznalo.Jogosultsag = "User";
            else
                felhasznalo.Jogosultsag = char.ToUpper(felhasznalo.Jogosultsag[0]) + felhasznalo.Jogosultsag.Substring(1).ToLower();
            var storedUser = await _context.Felhasznalok.FirstOrDefaultAsync(u => u.Email == felhasznalo.Email);
            if (storedUser != null)
            {
                return Conflict("Felhasználó már regisztrált!");
            }
            felhasznalo.Jelszo = PasswordHandler.HashPassword(felhasznalo.Jelszo);
            _context.Felhasznalok.Add(felhasznalo);
            await _context.SaveChangesAsync();
            return Created($"{Request.GetDisplayUrl()}/{felhasznalo.FelhasznaloId}", felhasznalo);
        }

        [Authorize(Policy = "Felhasznalo.Update")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, Felhasznalo felhasznalo)
        {
            if (string.IsNullOrWhiteSpace(felhasznalo.Email) || string.IsNullOrWhiteSpace(felhasznalo.Nev)
                || string.IsNullOrWhiteSpace(felhasznalo.Jelszo) || string.IsNullOrWhiteSpace(felhasznalo.Telefonszam))
            {
                return BadRequest("Hibás vagy hiányzó adatok!");
            }
            if (string.IsNullOrWhiteSpace(felhasznalo.Jogosultsag))
                felhasznalo.Jogosultsag = "User";
            else
                felhasznalo.Jogosultsag = char.ToUpper(felhasznalo.Jogosultsag[0]) + felhasznalo.Jogosultsag.Substring(1).ToLower();
            var list = await _context.Felhasznalok.ToListAsync();
            var oldFelhasznalo = list.FirstOrDefault(p => p.FelhasznaloId == id);
            if (oldFelhasznalo == null) return NotFound();
            foreach (var propInfo in typeof(Felhasznalo).GetProperties())
            {
                propInfo.SetValue(oldFelhasznalo, propInfo.GetValue(felhasznalo));
            }
            await _context.SaveChangesAsync();
            return Ok(oldFelhasznalo);
        }

        [Authorize(Policy = "Felhasznalo.Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            
            var felhasznalo = _context.Felhasznalok.FirstOrDefault(p => p.FelhasznaloId == id);
            if (felhasznalo == null) return NotFound();
            _context.Felhasznalok.Remove(felhasznalo);
            await _context.SaveChangesAsync();
            return Ok(felhasznalo);
        }
    }
}
